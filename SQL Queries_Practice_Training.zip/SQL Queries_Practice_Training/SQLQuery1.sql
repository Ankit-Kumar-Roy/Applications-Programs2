create table tblDepartment 
(
iDeptId int not null primary key,
cDeptName char(20),
vAddress varchar(20),
cDeptHead char(20)
)

insert into tblDepartment values (1,'Developer','Bangalore','Satish'),
(2,'Buisness','Bhubaneswar','Ravi'),(3,'Testing','Mysore','Alankar')

create table tblNewEmployee
(
iEmpId int not null primary key,
cName char(20),
vAddress varchar(20),
iSalary int,
iDeptId int references tblDepartment(iDeptId)
)

select cName,cDeptName tblEmployee join tblDepartment
 on tblEmployee.iDeptId=tblDepartment.iDeptId
 
insert into tblNewEmployee values (101,'Ankit','Patna',25000,1),
(102,'Rajnish','Ranchi',30000,2),(103,'Manish','Dhanbad',35000,3)
insert into tblNewEmployee values (104,'Abhishek','Delhi',38000,2),(105,'Padhi','Dhanbad',35000,1)

select * from tblDepartment
select * from tblEmployee
select cName,cDeptName from tblEmployee join tblDepartment
on tblEmployee.iDeptId=tblDepartment.iDeptId
select cDeptName,count(*) from select cName,cDeptName from tblEmployee join tblDepartment
on tblEmployee.iDeptId=tblDepartment.iDeptId group by cDeptName

select cDeptName,count(*) from tblEmployee join tblDepartment
on tblEmployee.iDeptId=tblDepartment.iDeptId group by cDeptName

select ASCII ('baA')
select CHAR(69)
select UPPER(LTRIM('      Hello')) as column1
select LoWER(LTRIM('      hELLO'))as column2





create table tblDepartment1
(
iDeptId int primary key not null,
cDeptName varchar(20),
vDeptLocation varchar(20),
cDeptHead varchar(20)
)

insert into tblDepartment1 values (1,'Development','bangalore','rajnish')
insert into tblDepartment1 values (2,'Account','chennai','manish')
insert into tblDepartment1 values (3,'Finance','pune','ankit')


create table tblNewEmployee1
(
iEmpId int primary key not null,
cName char(20),
vAddress varchar(50),
iSalary int,
iDeptId int references tblDepartment1 (iDeptId)
)

insert into tblNewEmployee1 values (101,'Rohan','karnataka',79238,1)
insert into tblNewEmployee1 values (102,'Mohan','tamilnadu',48294,2)
insert into tblNewEmployee1 values (103,'Johan','mumbai',82374,3)

select * from tblNewEmployee1

--create a view called vwEmpSalary

create view vwEmpSalary
as select cName as "Employee Name",iSalary as "Salary" from tblNewEmployee1

select * from vwEmpSalary

--nested view

create view vwEmpName
as select "Employee Name" from vwEmpSalary

select * from vwEmpName

update vwEmpSalary set Salary =60000 where [Employee Name]='Mohan'

select * from tblNewEmployee1

--dropping view
drop view vwEmpName





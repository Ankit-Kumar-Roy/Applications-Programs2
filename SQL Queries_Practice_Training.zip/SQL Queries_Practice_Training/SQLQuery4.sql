SELECT * FROM tblNewEmployee

--creating procedures/stored procedures

--create a procedure to display the records from employee
create procedure prcDisplayEmpRecords
as select *from tblNewEmployee

--executing the procedure
prcDisplayEmpRecords

--alternatively
exec prcDisplayEmpRecords

--create procedure to display Employee Name and their Department Name
--table prefix is nothing but an alias for table
--select e.cName,d.cDeptName from tblNewEmployee e JOIN tblDepartment d
--ON e.iDeptId=d.iDeptId ->these two rows are table prefix
--i.e-> tblNewEmployee.cName i.e tablename.columnname to simply avoid ambiguity
create proc prcDisplayEmpAndDeptName
as 
select e.cName,d.cDeptName from tblNewEmployee e JOIN tblDepartment d 
ON e.iDeptId=d.iDeptId

--for executing the procedure 
prcDisplayEmpAndDeptName

--parameterised procedures
--to display employee records based on location
-- a variable which starts with @ symbol are known as sql variables e.g->@address

create proc prcDisplaySpecificEmployee
@address varchar(20)
as
select * from tblNewEmployee where vAddress=@address
--execution
--parameter through which we can input the data in the procedure
prcDisplaySpecificEmployee
prcDisplaySpecificEmployee 'Ranchi'
prcDisplaySpecificEmployee 'dhanbad'


--nested procedure
--to display all employee and department records in single output


create proc prcDisplayEmp
as
select * from tblNewEmployee

create proc prcDisplayDepartment
as
select * from tblDepartment

--nested procedure

create proc prcDisplayBothEmpAndDepat
as
exec prcDisplayEmp --it is mandatory to use exec command inside nested procedure
exec prcDisplayDepartment

prcDisplayBothEmpAndDepat

--we can't have one create procedure inside another create statement

--output parameter in stored procedure

create procedure prcEmpDeptID
@EmpId int,
@EmpDepte char(20) OUTPUT
as
select @EmpDepte =cDeptName from tblDepartment
where iDeptId=@EmpId

declare @EmpDepte char(20)
exec prcEmpDeptID 1 ,@EmpDepte=@EmpDepte output
select  @EmpDepte


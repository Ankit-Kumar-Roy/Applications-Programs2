create table TriggerEmployee
(
iEmpId int primary key not null,
cEmpName varchar(20),
iSalary int,
cEmpGender char(10),
iDeptId int
)

insert into TriggerEmployee values (1,'John',5000,'male',3),(2,'Mike',3400,'Male',2),
(3,'Pam',6000,'Female',1),(4,'Todd',4800,'Male',4),
(5,'Sara',3200,'Female',1),(6,'Ben',4800,'Male',3)

create table EmployeeAuditData
(
Id int,
AuditData nvarchar(max)
)


create trigger tr_TriggerEmployee_ForInsert on TriggerEmployee
for insert
as
begin
select * from inserted
--declare @Id=int
--Select @Id=iEmpId from inserted
--insert into EmployeeAuditData 
--values('New Employee with Id='+ 
--CAST(@Id as varchar(5)) + is added at CAST(GetDate() as varchar(20))
end

insert into TriggerEmployee values (7,'Jane',1800,'Female',3)

alter trigger tr_TriggerEmployee_ForInsert on TriggerEmployee
for insert
as
begin
declare @Id int
Select @Id=iEmpId from inserted
insert into EmployeeAuditData 
values(@Id, 'New Employee with Id='+ 
CAST(@Id as varchar(5)) +' is added at' + CAST(GetDate() as varchar(20))
)
end

insert into TriggerEmployee values (9,'Maradona',4892,'Male',5)

select * from TriggerEmployee
select * from EmployeeAuditData



create table tblEmployee
(
iEmpId int primary key not null,
cEmpName char(20),
cGender char(10),
iDeptId int
)

insert into tblEmployee values (1,'sam','male',101),(2,'ram','male',101),
(3,'sara','female',103),(4,'Todd','male',102),(5,'john','male',103),
(6,'sana','female',102),(7,'steve','male',101)

select * from tblEmployee

--creating procedures

create proc prcGetEmployeeByGenderAndDepartment
@Gender varchar(20),
@DepartmentId int
as
begin
select cEmpName,cGender,iDeptId from tblEmployee where cGender=@Gender and iDeptId=@DepartmentId
end

create proc prcGetEmployees
as 
begin
select * from tblEmployee
end

prcGetEmployeeByGenderAndDepartment 'male',103
prcGetEmployees

sp_helptext prcGetEmployees
alter proc prcGetEmployees    
with encryption 
as
begin  
select * from tblEmployee order by cEmpName 
end

prcGetEmployees

create procedure prcGetEmployeeCountByGender
@Gender varchar(20),
@EmployeeCount int out
as 
begin 
select @EmployeeCount=COUNT(*) from tblEmployee where cGender=@Gender
end

declare @EmployeeCount int
exec prcGetEmployeeCountByGender @EmployeeCount=@EmployeeCount out,@Gender='male'
select @EmployeeCount as EmployeeCount


sp_depends tblEmployee




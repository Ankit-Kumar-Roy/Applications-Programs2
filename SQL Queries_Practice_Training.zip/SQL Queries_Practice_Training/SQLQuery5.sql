create table tblEmployee
(
iEmpId int,
sName char(20),
sCity char(15)
)

select * from tblEmployee

create proc prcAddRecord
@id int,
@name char(15),
@city char(15)
as 
insert into tblEmployee values(@id,@name,@city)

--Executing the procedure

prcAddRecord 999,'Suresh','Blore'


create table tblDateTime
(
c_Time time,
c_Date  date,
c_SmallDateTime smalldatetime,
c_DateTime datetime,
c_DateTime2 datetime,
c_datetimeoffset datetimeoffset
)

insert into tblDateTime values (GETDATE(),GETDATE(),GETDATE(),GETDATE(),GETDATE(),GETDATE())

select * from tblDateTime

update tblDateTime set c_DateTimeoffset='2017-01-18 11:09:06.6630000 +06:30'
where c_DateTimeoffset='2017-01-18 11:09:06.6630000 +05:30'

select GETDATE(),'GETDATE()'
select CURRENT_TIMESTAMP,'CURRENT_TIMESTAMP'
select SYSDATETIME(),'SYSDATETIME'
select SYSDATETIMEOFFSET(),'SYSDATETIMEOFFSET'
select GETUTCDATE(),'GETUTCDATE'
select SYSUTCDATETIME(),'SYSUTCDATETIME'

--ISDATE() examples
select ISDATE('PRAGIM') -- returns 0
select ISDATE(GETDATE())--RETURNS 1
select ISDATE('2017-01-19 10:51:56.050')--RETURNS 1
select ISDATE('2017-01-19 10:51:56.0500000')--RETURNS 0

--DAY(),MONTH(),YEAR() EXAMPLES
select DAY(GETDATE())
select DAY('2017-01-19 11:12:13.413')

select MONTH(GETDATE())
select MONTH('2017-01-19 11:12:13.413')

select YEAR(GETDATE())
select YEAR('2017-01-19 11:12:13.413')



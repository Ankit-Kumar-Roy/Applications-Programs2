-- String Functions--

--1.) LEN() (To Display the Lenght of the Given string)
--2.) DataLenght() (To Return number of bytes that is used)
--3.) Left() (To diplay the number of characters from the left of the given string)
--4.) Right() (To diplay the number of characters from the Right of the given string)
--5.) LOWER() (To display the given string in Lower Case)
--6.) UPPER() (To display the given string in Upper Case)
--7.) STR() (Converts the numeric value to character value)
--8.) LTRIM() (Removes any White Spaces From Left of the String)
--9.) RTRIM() (Removes any White Spaces from Right of the String)
--10.) SUBSTRING() (To Serach and Remove or disply the string)
--11.) Replace() (To Replace From the Given String)




SELECT LEN( 'Satyam')

SELECT DATALENGTH(N'Satyam')

SELECT LEFT('MahindraSatyam',10)

SELECT RIGHT('MahindraSatyam',6)

select Upper('mahindra')

select Lower('MAHINDRA')

select LTRIM('     ELTP977')

select RTRIM('ELTP977   ')

select TRIM('ELTP  996  abc')

SELECT SUBSTRING('MahindraSatyam',0,8)

SELECT REPLACE('Mahindra','a', 'SAT')

create type clients from
varchar(50) null

create rule rule_5
as @clientname='TechM'

sp_bindrule rule_5,'clients'
sp_unbindrule rule_5,'clients'

create table address
(
city_name varchar(25),
state_name clients
)
sp_help address

drop rule rule_5
select * from dept

select * from emp

SELECT dept.deptno,dept.dname,emp.emno,emp.nam,emp.dept
FROM dept CROSS JOIN emp ON dept.dept_dno=emp.emp_emno
                     
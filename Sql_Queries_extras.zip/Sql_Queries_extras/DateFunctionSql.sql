-- CURRENT_TIMESTAMP Function To Display the Current Time Stamp

--We Will Look in the Date Functions

--1.)DATEADD()
--2.)Convert Function
--3.)DateDiff()
--4.)DateName() Function
--5.)DatePart() Function
--6.)GetDate()
--7.)GETUTCDATE()(Returns GMT Time)
--8.)ISDATE() (Evaluating Whether An Expression Is a Date or Is Numeric)


--1.) DATEADD()----

select GETDATE()
select SYSDATETIME()
set dateformat mdy 103

dbcc useroptions 

select convert(nvarchar(35),getdate(),103)
select convert(int,getdate(),103)
select "Date"=CURRENT_TIMESTAMP

--- To CONVERT the DATE into VARCHAR DataType and Display
--- We Use CONVERT()

SELECT CONVERT(VarChar(20), GETDATE(),103)

-- Using DATEADD() Function
-- We can Add Months,Days,Years,Weeks to the Specified Date

--To Add 12 Days to the Specified Date using DATEADD Function
SELECT DATEADD(d,12,'28 July 2011')

--To Add 1 Month to the Specified Date Using DATEADD Function
SELECT DATEADD(m,1,'28 July 2011')

--To Add 2 Years to the Specified Year using DATEADD Function
SELECT DATEADD(yy,2,'28 July 2011')


--To Add 1 Week to the Specified Week using DATEADD Function
SELECT DATEADD(wk,1,'28 July 2011')

--To Remove 30 minutes from the Specified Time
SELECT DATEADD(mi, -30, '2005-09-01 23:30:00.000')

--To Remove 1 Month from the Specified month in the format
select DATEADD(month, -1, '2011-08-28 11:35:00')


--To Remove 1 Month from the specified date and display
SELECT CONVERT(VarChar(20), DATEADD(m,-1,'28 July 2011'))

select GETDATE()
----2.)DATEDIFF()---

---DATEDIFF() Returns the Differences between Two given dates---

SELECT DATEDIFF(dd,'2017-02-16','1012-04-23')

--DATEDIFF() Using Convert() to CONVERT and Display

SELECT "DateDifferences"=CONVERT(varchar(30),DATEDIFF(dd,'28 Jun 2011','28 July 2011'))


--DATEDIFF() To display the differneces between two given months

SELECT "DateDifferences"=CONVERT(varchar(30),DATEDIFF(m,'28 Jun 2011','28 July 2011'))

--DATEDIFF() To display the differneces between two given years

SELECT "DateDifferences"=CONVERT(varchar(30),DATEDIFF(yy,'28 Jun 2000','28 July 2010'))


----To Get the Differences in hours Between UTC Date and Current Date
SELECT DATEDIFF(minute, GETDATE(), GETUTCDATE())


--4.) DateName()---

----To Display the Month Name,Week Name we can use DateName()---

SELECT DATENAME(mm,GETDATE())



--Find out the Month Name in the Two Given Months
--It Will Add 1 month to the current Month display the Month Name
SELECT DATENAME(mm,DATEADD(mm,1,GETDATE()))


--To Display the Week Name from the specified date
select DATENAME(weekday, '2011-07-31')


--5.) DatePart() which can Display the Week,Weekday,month,date,year etc...

--Abbreviations of Date Parts

Datepart      Abbreviation
year          yy, yyyy
quarter       qq, q
month         mm, m
dayofyear     dy, y
day           dd, d
week          wk, ww
weekday       dw
hour          hh
minute        mi, n
second        ss, s
millisecond   ms

select DATEPART(weekday, '2002-09-30 11:35:00')
select DATEPART(ww, '2002-01-30 11:35:00')


select DAY('29 July 2011')


--To Add No Of Days to the Specified Days using  + operator
SELECT GETDATE () + 2


--Returns the Current GeenWichMeanTime(GMT)
Select GETUTCDATE()

SELECT ISDATE('1/1/2000')


---7.) ISDATE() Evaluating Whether An Expression Is a Date or Is Numeric

SELECT ISDATE('28 july 2011')

----DAY(),MONTH(),YEAR() Function to Return Current Date,Month,Year---

SELECT 'Year: ' + CONVERT(VarChar(4), YEAR(GETDATE()))
       + ', Month: ' + CONVERT(VarChar(2), MONTH(GETDATE()))
       + ', Day: ' + CONVERT(VarChar(2), DAY(GETDATE()))

select GETDATE()

set dateformat dmy
select getdate()

set DateFormat dmy
select CONVERT(VarChar(40), GETDATE())



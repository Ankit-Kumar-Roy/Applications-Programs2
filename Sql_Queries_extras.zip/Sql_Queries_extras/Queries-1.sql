--To Modify the Database Size based on 
--FileGroup(.mdf,.ndf,.ldf)
alter database d111
MODIFY FILE 
(Name='C:\Program Files\Microsoft SQL Server\MSSQL.1\MSSQL\Data\d111.mdf',
SIZE=10MB)

/* To Display the complete information of a DB*/
sp_helpdb HRMS1
/* To Rename a Current DB*/
sp_renamedb 'Test','Test123'


sp_spaceused 
sp_rename 'oldtablename','newtablename'
drop database d111
drop table TableName
--To Compress a DB
DBCC SHRINKDATABASE(dinesh,1)

select * from sys.objects
--To Find out the list of avalibale DB'S
select * from sys.sysdatabases 
--list of all the avaialbe logins
select * from sys.syslogins 
--To find out list of allthe tables in
--the current DB

--To modify the datatype of the table
alter table bank
alter column lnam varchar(50)


alter table bank
add MobileNumber int 

--To add the column to the existing table

alter table bank
add phoneNo int


--To drop already existing column from the table

alter table bank
drop column mobile_number

--To display the name of the table object in the current database
SELECT * FROM sys.sysobjects 
WHERE Name = 'Employee'




--To display the name of the database if it exists
--if exists (select * from sys.databases where name='pubs')
--begin
--raiserror('Dropping existing pubs database ....',0,1)
--end

--To display all the database names

select * from sys.databases

--To display the structure of the table
sp_help bank

--To Modify the existing database and add a file
ALTER DATABASE Test1
MODIFY FILE
( NAME = 'test1dat3',
SIZE = 20MB)

--To Backup the database to a drive
BACKUP DATABASE SampleDB 
to disk ='E:\Copy Of All\SampleDB.bak'


--To Restore the database
RESTORE DATABASE 
NWCopy FROM 'E:\Copy Of All\SampleDB.bak'
--WITH NORECOVERY


--To display help for the specified login
sp_helpuser 'ELTP'

--To know what is the name of the current database
select DB_NAME()

--To Display the size of the data types for the specified column the table
SELECT COL_LENGTH('bank', 'amount')
sp_help bank

--To Display what are the depended objects on the table bank
sp_depends bank

--To Display all the logins in the sqlserver

select * from sys.syslogins

--To Display the logins 
select * from sys.sysusers


select * from dept1
where DEPT_ID=1001 or 
Dept_Location='e'
--To Create a new table
create table EMP_90
(
Emp_ID varchar(30),
Emp_Name varchar(40),
Emp_Salary int
)
select * from emp_90
-- To Insert rows into EMP_90 Table
insert into emp_90 values('E003','Rak',9008)

delete from emp_90
where emp_id='e001'


select host_name()
select @@connections

select * from emp_90

select emp_id emp_name,
emp_salary=emp_salary  + emp_salary *0.1
from emp_90

select * from emp_90
where emp_salary >= 1000 and 
emp_salary <=500

select * from emp_90
where emp_salary between 
1000 and 5000

select * from Emp001
where emp_salary not in(8000,9000)

select * from Emp001
where emp_name like 'ra%'

select * from emp001
where emp_name='Eric'

select * from emp001
where emp_name exists 



update emp001
set emp_salary=emp_salary + emp_salary * 0.2
where emp_id='e003'

update emp001
set emp_salary=
case 
when emp_id='E001'
then emp_salary + emp_salary * 0.1
--case 2
when emp_id='E002'
then emp_salary +  emp_salary * 0.2
--else
--emp_salary
end
where emp_id = 'E001' or emp_id='E002'

select * into emp005 from emp001

SELECT * FROM EMP001
WHERE emp_name like '%[^E-J]%'

select * from emp001
--where emp_id like 'E%'
order by dept_id,emp_id desc

select "Employee_Salary"= SUM(emp_salary) 
from emp001

select emp_id,sum(emp_salary)
from emp001
where emp_id='E001'
group by emp_id
having sum(emp_salary) >= 3000

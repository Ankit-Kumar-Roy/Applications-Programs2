
--- Stored Procedures Introduction ---

--1.) A stored procedure is made of one or more SQL statements 
---   that have been compiled and stored with database. 

--2.) Stored procedure can improve database performance 
---   because the SQL statements in each procedure are only 
---   compiled and optimized the first time they are executed.

--3.)In addition to SELECT statement, a stored procedure can contain 
---  other SQL statements such as INSERT,UPDATE,DELETE.  

--4.) A trigger is a special type of procedure that executes 
----  when rows are inserted, updated or deleted from table.

---5.)A user defined function(UDF) is a special type of procedure 
---   that can return a value or a table.


---Types of Stored Proc's-----
--1.) User Defined Stored Procedures
-----a.)IN Parameter Stored Procedure
-----b.)OUT Parameter Stored Procedure
---2.) System Defined Stored Procedures
 

---Example-1 on how to create a stored procedure

create proc usp_InsertEmp
@empid int,
@Deptid int,
@empname varchar(35),
@empaddress varchar(35),
@empsalary int
as
begin
declare @empid1 as int
declare @deptid1 as int
declare @empname1 as varchar(35)
declare @empaddress1 as varchar(35)
declare @empsalary1 as int
Set @empid1=@empid
set @deptid1=@deptid1
set @empname1 =@empname
set @empaddress1=@empaddress
set @empsalary1=@empsalary
insert into Emp_01 
values(@empid1,@deptid1,@empname1,@empaddress1,@empsalary1) 
print 'The Values have been inserted sucessfully'
end










Alter PROCEDURE sp_Dept_elp967 
          @DeptName varchar(30)
AS
BEGIN
          -- SET NOCOUNT ON added to prevent extra result sets from
          -- interfering with SELECT statements.
          SET NOCOUNT ON;

          -- Insert statements for procedure here
          SELECT Dept_ID,Dept_Name,Dept_Location
          FROM Dept_elp967 Where Dept_Name = @DeptName ORDER BY Dept_Location desc

END


---Example-2 To display the values----
Create procedure usp_disp1
@empname varchar(35)
as
begin
	declare @deptid int,@empsalary int
	select @deptid = dept_id,@empsalary=emp_salary 
	from emp_01
    where emp_name =@empname
	print 'Dept ID' + (Convert(varchar(35),@deptid))
	print 'Emp Salary ' + (Convert(varchar(35),@empsalary))
end

--Example-3 Stored Procedure to reterive particular category

CREATE PROCEDURE getcategory 
@parentcategoryid int,
@categoryid int output,
@categoryname char(200) output
as
declare @cur  int
declare @count int
select parentcategoryid ,parentcategoryname 
from parentcategories
SELECT @count=COUNT(categoryId) FROM 
category GROUP BY 
parentCategoryId
HAVING(parentCategoryId = 1)
if (@count)>0
begin
while(@cur<@count)
begin
select categoryid,parentcategoryid,categoryname 
from category where parentcategoryid=@parentcategoryid
end
end


---Example-4 Stored procedure for searching a particular item

CREATE Procedure ProductSearch
(@Search nvarchar(255))
AS
SELECT ProdID,ModelName,Costsmall,ProductImage,description
FROM Products 
WHERE ModelName 
LIKE '%' + @Search + '%'   
OR    
Description LIKE '%' + @Search + '%'   OR    
comments LIKE '%' + @Search + '%'





---Example 5 Check for a particular product is avaiable and update
----the category like-wise
CREATE Procedure ShoppingCartAddItem
(@CartID nvarchar(50),    
 @ProductID int,    
 @Quantity int)
As
DECLARE @CountItems int
SELECT @CountItems = Count(ProdID)FROM    
ShoppingCart WHERE ProdID = @ProductID  
AND CartID = @CartID
IF @CountItems > 0  
/* There are items - update the current quantity */    
UPDATE ShoppingCart SET Quantity = (@Quantity + ShoppingCart.Quantity)
WHERE ProdID = @ProductID      
AND CartID = @CartIDELSE  
/* New entry for this Cart.  Add a new record */    
INSERT INTO ShoppingCart(CartID,Quantity,ProdID)
VALUES(@CartID,@Quantity,@ProductID)



----Example-6 usage of try catch and print statement(Very Important)----

alter procedure ques1 
@empid int 
as
begin try
declare @empname varchar(30)
declare @empsalary int
declare @msg nvarchar(35)
declare @esev nvarchar(35)
declare @estat nvarchar(35)
declare @erln nvarchar(35)
--declare @empid1 int
select @empsalary = emp_salary,@empname=emp_name from emp_01
where emp_id = @empid
if @empsalary >= 4000 and @empsalary <=10000
begin
update emp_01 set  emp_salary=Emp_Salary + 500
print 'empname is' + @empname
end
if @empsalary >= 12000
begin
	raiserror('invalid salary' , 16 , 1)
end
end try
begin catch
select  @msg  = ERROR_MESSAGE() , @esev = ERROR_SEVERITY() , 
			@estat  = ERROR_STATE() , @erln = ERROR_LINE()
print 'Error message ' + @msg
print ' Error severity' +@esev
print  ' Error state ' + @estat
print ' Error line number ' + @erln
end catch

select * from emp_01
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;


namespace StoredProcedureSelectCityOut
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the id");
            int empid = Convert.ToInt32(Console.ReadLine());

            SqlConnection con = new SqlConnection(@"Server=INBASDPC11337\SQLEXPRESS;Database=dbEmpManagement;Integrated Security=true");
            con.Open();

            SqlCommand cmd = new SqlCommand("exec uspSelectCityOut @id, @city out");

            cmd.Connection = con;
            cmd.Parameters.AddWithValue("@id", empid);
            cmd.Parameters.Add("@city",SqlDbType.VarChar,20);
            cmd.Parameters["@city"].Direction = ParameterDirection.Output;

            try
            {
                cmd.ExecuteScalar();
                Console.WriteLine("City: {0}", cmd.Parameters["@city"].Value.ToString());
            }
            catch (Exception)
            {

                //Console.WriteLine(e);
                //Console.WriteLine("Id already exists");

            }
            finally
            {
                con.Close();
            }
            Console.Read();
        }
    }
}

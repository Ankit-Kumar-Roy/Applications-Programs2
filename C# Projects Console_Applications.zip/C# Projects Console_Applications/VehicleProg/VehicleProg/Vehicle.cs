﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VehicleProg
{
    class Vehicle
    {
        private string name;
        private readonly int vehId;
        private int noOfModels = 0;
        public static int CountVehicles = 0;
        public List<Model> modelList = new List<Model>();
        public List<List<Model>> vehicleList = new List<List<Model>>();

        public Vehicle()
        {

        }

        public Vehicle(string name, int id, int noOfModels)
        {
            this.Name = name;
            if (id >= 1)
                this.vehId = id;
            else
                Console.WriteLine("Id cannot be less than 1");
            this.noOfModels = noOfModels;
        }

        public bool IsAlpha(string s)
        {
            foreach (char c in s.ToCharArray())
            {
                if (!Char.IsLetter(c))
                {
                    return false;
                }
            }
            return true;
        }

        public string Name
        {
            get
            {
                return name;
            }
            set
            {
                string input = value;
                if (IsAlpha(input))
                    name = input;
                else
                    Console.WriteLine("Improper input for name, please make sure that the name contains only alphabets");
            }
        }

        public int Id 
        { 
            get
            {
                return vehId;
            }
        }

        public int NoOfModels
        {
            get
            {
                return noOfModels;
            }
            set
            {
                noOfModels = value;
            }

        }
    }
}

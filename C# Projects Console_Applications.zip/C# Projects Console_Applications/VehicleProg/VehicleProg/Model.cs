﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading.Tasks;

namespace VehicleProg
{
    class Model : Vehicle,IVatCalc
    {
        private int id;
        private string model;
        private double price;
        private bool instock;
        private static int idcounter = 1;    
        public int Price { get; set; }

        public override string ToString()
        {
            return "\nType:"+Name+" Model ID: " + id + " Model: " + model + " Price: " + price + " instock: " + instock;
        }

        public Model()
        {

        }

        public Model(string name, string model, double price, bool instock)
        {
            this.Name = name;
            this.id = idcounter++;
            this.model = model;
            this.price = price;
            this.instock = instock;
        }

        public Model(Model m)
        {
            this.Name = m.Name;
            this.model = m.model;
            this.price = m.price;
            this.instock = m.instock;
        }

        public bool check_available()
        {
            return instock;
        }

        public Model add_model(Model m,string name,List<Model> li)
        {

            Model m1 = new Model();
            m1.id = m.id;
            m1.Name = m.Name;
            m1.model = m.model;
            m1.price = m.price;
            m1.instock = m.instock;
            CountVehicles++;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("\nRecord Inserted");
            Console.ResetColor();
            return m1;

        }

        public void delete_model(List<Model> li)
        {
            if (li.Count != 0)
            {
                int id = HoldMethods.IntInput("Enter the model ID whose records you want to delete: ");
                int i, flag = 0;
                for (i = 0; i < li.Count; i++)
                {
                    if (li[i].id == id)
                    {
                        flag = 1;
                        break;
                    }
                }
                if (flag == 1)
                {
                    li.Remove(li[i]);
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("\nRecord Deleted!");
                    Console.ResetColor();
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("\nRecord doesn't exist");
                    Console.ResetColor();
                }
            }
            else
            {
                MessageBox.Show("\nNo models available");
            }
        }

        public void display_all_models(List<Model> li)
        {
            if (li.Count!=0)
            {
                 foreach (Model m in li)
                    {
                        Console.WriteLine(m);
                    }
            }
            else
            {
                MessageBox.Show("\nNo models are available in the list");
            }
        }

        public void modify_price(List<Model> li)
        {
            if (li.Count != 0)
            {
                int id = HoldMethods.IntInput("Enter the model ID whose price you want to modify: ");
                int i, flag = 0;
                for (i = 0; i < li.Count; i++)
                {
                    if (li[i].id == id)
                    {
                        flag = 1;
                        break;
                    }
                }
                if (flag == 1)
                {
                    Console.Write("Enter a new price: ");
                    try
                    {
                        li[i].price = Convert.ToDouble(Console.ReadLine());
                    }
                    catch (Exception)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Improper input");
                        Console.ResetColor();
                    }
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("\nId doesn't exists");
                    Console.ResetColor();
                }
            }
            else
            {
                MessageBox.Show("\nNo models available in the list");
            }
        }

        public void lowest_price_model(List<Model> li)
        {
            if (li.Count != 0)
            {
                double lowest = li[0].price;
                for (int i = 0; i < li.Count; i++)
                {
                    if (li[i].price < lowest)
                    {
                        lowest = li[i].price;
                    }
                }
                Console.WriteLine("\nThe lowest price is: {0}", lowest);
            }
            else
            {
                MessageBox.Show("\nNo models are available in the list");
            }
        }

        public void display_models_of_specific_price(List<Model> li)
        {

            if (li.Count != 0)
            {
                double p = HoldMethods.DoubleInput("Enter the price: ");
                int flag = 0;
                Console.WriteLine("\nThe models whose cost is {0} are: ", p);
                foreach (Model i in li)
                {
                    if (i.price == p)
                    {
                        flag = 1;
                        Console.WriteLine(i);
                    }
                }
                if (flag == 0)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("\nNo models exist for this price");
                    Console.ResetColor();
                }
            }
            else
            {
                MessageBox.Show("\nNo models are available in the list");
            }
        }
        public void modelsIn_Aprice_range(List<Model> li)
        {
            if (li.Count != 0)
            {
                double lp = HoldMethods.DoubleInput("Enter the lowerbound: ");
                double up = HoldMethods.DoubleInput("Enter the upperbound: ");
                int flag = 0;
                Console.WriteLine("\nThe models whose cost is within {0} and {1} are: ", up, lp);
                for (int i = 0; i < li.Count; i++)
                {
                    if (li[i].price < up && li[i].price > lp)
                    {
                        flag = 1;
                        Console.Write(li[i]);
                    }
                }
                if (flag == 0)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("\nNo models exist in this range");
                    Console.ResetColor();
                }
            }
            else
            {
                MessageBox.Show("\nNo models are available in the list");
            }
        }

        public void display_1model(List<Model> li)
        {
            if (li.Count != 0)
            {
                int id = HoldMethods.IntInput("Enter the model ID whose price you want to modify: ");
                foreach (Model i in li)
                {
                    if (i.id == id)
                    {
                        Console.WriteLine(i);
                        return;
                    }
                }
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("\nNo records found for this model");
                Console.ResetColor();
            }
            else
            {
                MessageBox.Show("\nNo models are available in the list");
            }
        }
        public void check_available(List<Model> li)
        {
            if (li.Count != 0)
            {
                int id = HoldMethods.IntInput("Enter the id of the model whose availability is to be found: ");
                foreach (Model i in li)
                {
                    if (i.id == id)
                    {
                        if (i.instock)
                        {
                            Console.ForegroundColor = ConsoleColor.Green;
                            Console.WriteLine("\nThis model is in stock");
                            Console.ResetColor();
                            return;
                        }
                        else
                        {
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("\nThis model is not in stock");
                            Console.ResetColor();
                            return;
                        }
                    }
                }
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("\nNo records found for this model");
                Console.ResetColor();
            }
            else
            {
               MessageBox.Show("\nNo models are available in the list");
            }
        }

        public void calculate_VAT(List<Model> li)
        {
            int idInserted = HoldMethods.IntInput("Enter the model ID whose VAT you want to know: ");
            int flag = 0;
            foreach (Model item in li)
            {
                if (item.id == idInserted)
                {
                    Console.WriteLine("\nThe VAT to be paid is: {0}", item.price * 0.045);
                    flag = 1;
                    break;
                }
            }
            if (flag == 0)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("The ID doesn't exist");
                Console.ResetColor();
            }
        }
    }

}

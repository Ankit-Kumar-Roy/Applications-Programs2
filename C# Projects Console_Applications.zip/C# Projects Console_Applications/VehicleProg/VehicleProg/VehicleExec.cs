﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VehicleProg
{
    class VehicleExec
    {
        static void Main(string[] args)
        {
            Model mod = new Model();
            Vehicle car = new Vehicle();
            Vehicle van = new Vehicle();
            Vehicle stationWagon = new Vehicle();
             
            int ch;
            do
            {
                HoldMethods.VehicleMenu();
                string choice = Console.ReadLine();
                if (choice.Equals("1"))
                {
                    
                    HoldMethods.ShowMenu();
                    
                    ch = HoldMethods.IntInput("\nPlease enter your choice: ");
                    HoldMethods.ModelOperations(mod, car, ch, "Car");
                }
                else if (choice.Equals("2"))
                {
                    
                    HoldMethods.ShowMenu();

                    ch = HoldMethods.IntInput("\nPlease enter your choice: ");
                    HoldMethods.ModelOperations(mod, van, ch, "Van");
                }
                else if (choice.Equals("3"))
                {
                    
                    HoldMethods.ShowMenu();

                    ch = HoldMethods.IntInput("\nPlease enter your choice: ");
                    HoldMethods.ModelOperations(mod, stationWagon, ch, "Storage Wagon");
                }
                else if (choice.Equals("0"))
                {
                    Environment.Exit(0);
                }
                else
                    Console.WriteLine("Improper Input");
            }while(true);
        }
    }
}


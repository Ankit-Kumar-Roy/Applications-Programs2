﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VehicleProg
{
    enum SwitchOptions
    {
        Exit, AddModel, DeleteModel, DisplayAllModels, ModifyPrice, LowestPriceModel, DisplayModelsOfSpecificPrice, ModelsInAPriceRange, Display1Model, CheckAvailability, VehicleCount, CalculateVAT
    }

    class HoldMethods
    {
        

        public static void VehicleMenu()
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("\nEnter the vehicle type: "); 
            string[] str = { "1 for Car", "2 for Van", "3 for Storage Wagon", "0 to exit" };
            foreach (string s in str)
            {
                Console.WriteLine(s);
            }
            Console.ResetColor();
            Console.Write("\nEnter your choice: ");
        }

        public static void ModelOperations(Model mod, Vehicle veh, int ch, string type)
        {
            switch ((SwitchOptions)ch)
            {
                case SwitchOptions.Exit:
                    break;
                case SwitchOptions.AddModel:
                    {
                        Model mod1 = ModelDetails(type);
                        veh.modelList.Add(mod.add_model(mod1, type, veh.modelList));
                        break;
                    }
                case SwitchOptions.DeleteModel:
                    {
                        mod.delete_model(veh.modelList);
                        break;
                    }
                case SwitchOptions.DisplayAllModels:
                    {
                        mod.display_all_models(veh.modelList);
                        break;
                    }
                case SwitchOptions.ModifyPrice:
                    { 
                        mod.modify_price(veh.modelList);
                        break;
                    }
                case SwitchOptions.LowestPriceModel:
                    {
                        mod.lowest_price_model(veh.modelList);
                    }
                    break;
                case SwitchOptions.DisplayModelsOfSpecificPrice:
                    {
                        mod.display_models_of_specific_price(veh.modelList);
                    }
                    break;
                case SwitchOptions.ModelsInAPriceRange:
                    {
                        mod.modelsIn_Aprice_range(veh.modelList);
                        break;
                    }
                case SwitchOptions.Display1Model:
                    {
                        mod.display_1model(veh.modelList);
                        break;
                    }
                case SwitchOptions.CheckAvailability:
                    {
                        mod.check_available(veh.modelList);
                        break;
                    }
                case SwitchOptions.VehicleCount:
                    {
                        Console.WriteLine("The total no of vehicles are: {0}", Vehicle.CountVehicles);
                        break;
                    }
                case SwitchOptions.CalculateVAT:
                    {
                        mod.calculate_VAT(veh.modelList);
                        break;
                    }
                default:
                    {
                        Console.WriteLine("Improper Choice");
                        break;
                    }
            }

            
        }

        public static Model ModelDetails(string type)
        {
            Console.WriteLine();
            Console.Write("Enter model name: ");
            string model = Console.ReadLine();
            double price = DoubleInput("Enter price: ");
            bool instock = BooleanInput("Enter availability (true/false): ");
            Model mod1 = new Model(type, model, price, instock);
            return mod1;
        }

        public static double DoubleInput(string msg)
        {
            double mprice;
            Console.Write(msg);
            while (true)
            {

                if (double.TryParse(Console.ReadLine(), out mprice))
                {
                    return mprice;
                }
                Console.WriteLine("Sorry! improper input, please enter a double value");
            }
        }

        public static bool BooleanInput(string msg)
        {
            bool instock;
            Console.Write(msg);
            while (true)
            {

                if (bool.TryParse(Console.ReadLine(), out instock))
                {
                    return instock;
                }
                Console.WriteLine("Sorry! improper input, please enter a boolean value");
            }
        }

        public static int IntInput(string msg)
        {
            int mid;
            Console.Write(msg);
            while (true)
            {
                if (int.TryParse(Console.ReadLine(), out mid))
                {
                    return mid;
                }
                Console.WriteLine("Sorry! improper input, please enter an integer value");
            }
        }

        public static void ShowMenu()
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            string[] menu = { "\nPlease select what you want to do", "1.Add model", "2.Delete model", "3.Display all models", "4.Modify price", "5.Display lowest priced model", "6.Display all models in a given price", "7.Display all models in a given price range", "8.Display details of a model on the basis of model number", "9.Check if a model is available", "10.Get the count of the vehicles", "11.Calculate VAT", "0.Try another vehicle" };

            foreach (string str in menu)
            {
                Console.WriteLine(str);
            }
            Console.ResetColor();
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace com.myprogs.Multiples3_5
{
    public class Multiples3_5
    {
        static void Main()
        {
            Console.WriteLine("The multiples of 3 and 5 within 1 to 100 are:");
            for(int i=1;i<=100;i++)
            {
                if (i % 3 == 0 && i % 5 == 0)
                {
                    Console.Write(i + " ");
                }
                else continue;
            }
            Console.Read();
        }
    }
}

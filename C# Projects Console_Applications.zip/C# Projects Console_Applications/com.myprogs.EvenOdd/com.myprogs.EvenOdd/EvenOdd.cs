﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace com.myprogs.EvenOdd
{
    public class EvenOdd
    {
        public static void Main()
        {
            int iNum;

            Console.WriteLine("Enter the number:");
            iNum = Convert.ToInt32(Console.ReadLine());

            if (iNum % 2 == 0)
            {
                Console.WriteLine("Is Even");
            }
            else
            {
                Console.WriteLine("Is Odd");
            }
            Console.Read();
        }
    }
}

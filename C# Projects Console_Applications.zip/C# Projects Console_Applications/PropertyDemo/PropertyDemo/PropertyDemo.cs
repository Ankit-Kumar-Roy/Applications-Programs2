﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PropertyDemo
{
    class PropertyDemo
    {
        int age;
        PropertyDemo()
        {

        }
        PropertyDemo(int age)
        {
            this.age = age;
        }
        //use of property in data validation
        public int Age
        {
            get
            {
                return age;
            }
            set
            {
                if(value > 60)
                {
                    age = 0;
                    Console.WriteLine("Please enter a valid age");
                }
                else
                {
                    age = value;
                }
            }
        }
        public override string ToString()
        {
            return "Age=" + age;
        }
        
        static void Main(string[] args)
        {
            PropertyDemo obj = new PropertyDemo();
            Console.Write("Enter age: ");
            obj.Age = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Person details {0}",obj);
            Console.Read();
        }
    }
}

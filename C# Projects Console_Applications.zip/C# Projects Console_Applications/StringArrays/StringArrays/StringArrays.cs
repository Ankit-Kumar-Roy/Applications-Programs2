﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringArrays
{
    public class StringArrays
    {
        static void Main()
        {
            //string[] name = { "abc", "pqr", "xyz" };
            //foreach(string s in name)
            //{
            //    Console.WriteLine(s);
            //}
            //Console.Read();

            string[] name = new string[5];
            Console.WriteLine("Enter five names:");
            for(int i=0;i<name.Length;i++)
            {
                name[i] = Console.ReadLine();
            }
            Console.WriteLine("The names are:");
            foreach(string s in name)
            {
                Console.WriteLine(s);
            }
            Console.Read();
        }

    }
}

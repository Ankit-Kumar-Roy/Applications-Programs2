﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StaticConstructor
{
    class StaticConstructorDemo
    {
        static void Main(string[] args)
        {
            StaticConstructor obj1 = new StaticConstructor();
            StaticConstructor obj2 = new StaticConstructor();
            Console.Read();
        }
    }

    class StaticConstructor
    {
        static int localintvar;

        static StaticConstructor() //We cannot use a public access specifier here as access modifiers are not allowed on static constructors 
        {
            Console.WriteLine("Static Constructor is called");
            localintvar = 10;
        }

        public StaticConstructor()
        {
            Console.WriteLine("Constructor is called");
        }
    }
}

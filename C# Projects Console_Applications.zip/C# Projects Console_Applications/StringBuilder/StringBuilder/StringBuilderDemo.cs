﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringBuilderDemo
{
    class StringBuilderDemo
    {
        static void Main(string[] args)
        {
            string s = "Carl";
            StringBuilder b1 = new StringBuilder(s.Length + 12);
            StringBuilder b5 = new StringBuilder();
            Console.WriteLine(b5.MaxCapacity);
            Console.WriteLine(b1.Capacity);

            b1.Append("Carl");
            b1.Append("-uli");
            b1.AppendLine();

            Console.WriteLine(b1);
            b1.Remove(3, 2);
            Console.WriteLine(b1);
            StringBuilder b2 = new StringBuilder("A.C");
            b2.Insert(2, "B.");
            Console.WriteLine(b2);
            b2.Replace('.', ';');
            Console.WriteLine(b2);
            StringBuilder b3 = new StringBuilder("stringbuilder");
            b3.Remove(4, 4);
            //b3.Remove(4, 9);
            Console.WriteLine(b3);
            Console.Read();
        }
    }
}

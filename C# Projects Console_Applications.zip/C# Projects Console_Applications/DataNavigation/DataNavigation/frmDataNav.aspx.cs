﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Web.UI.WebControls;

namespace DataNavigation
{
    public partial class frmDataNav : System.Web.UI.Page
    {
        static int rowCount = 0;
        protected void Page_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"server =INBASDPC11337\SQLEXPRESS;Database=dbEmpManagement;Integrated Security =true");
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from tblNewEmployee", con);
            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = cmd;
            DataSet ds = new DataSet();
            da.Fill(ds, "tblNewEmployee");
            DataTable dt = ds.Tables["tblNewEmployee"];
            txtId.Text = dt.Rows[0][0].ToString();
            txtName.Text = (string)dt.Rows[0][1];
            txtCity.Text = (string)dt.Rows[0][2];
        }

        protected void btnFirst_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"server =INBASDPC11337\SQLEXPRESS;Database=dbEmpManagement;Integrated Security =true");
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from tblNewEmployee", con);
            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = cmd;
            DataSet ds = new DataSet();
            da.Fill(ds, "tblNewEmployee");
            DataTable dt = ds.Tables["tblNewEmployee"];
            txtId.Text = dt.Rows[0][0].ToString();
            txtName.Text = (string)dt.Rows[0][1];
            txtCity.Text = (string)dt.Rows[0][2];
        }

        protected void btnPrevious_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"server =INBASDPC11337\SQLEXPRESS;Database=dbEmpManagement;Integrated Security =true");
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from tblNewEmployee", con);
            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = cmd;
            DataSet ds = new DataSet();
            da.Fill(ds, "tblNewEmployee");
            DataTable dt = ds.Tables["tblNewEmployee"];
            rowCount = rowCount - 1;
            try
            {
                txtId.Text = dt.Rows[rowCount][0].ToString();
                txtName.Text = (string)dt.Rows[rowCount][1];
                txtCity.Text = (string)dt.Rows[rowCount][2];
            }
            catch(Exception)
            {
                MessageBox.Show("You are already at the first page");
                rowCount = rowCount + 1;
                txtId.Text = dt.Rows[rowCount][0].ToString();
                txtName.Text = (string)dt.Rows[rowCount][1];
                txtCity.Text = (string)dt.Rows[rowCount][2];
            }
        }

        protected void btnNext_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"server =INBASDPC11337\SQLEXPRESS;Database=dbEmpManagement;Integrated Security =true");
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from tblNewEmployee", con);
            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = cmd;
            DataSet ds = new DataSet();
            da.Fill(ds, "tblNewEmployee");
            DataTable dt = ds.Tables["tblNewEmployee"];
            rowCount = rowCount + 1;
            try
            {
                txtId.Text = dt.Rows[rowCount][0].ToString();
                txtName.Text = (string)dt.Rows[rowCount][1];
                txtCity.Text = (string)dt.Rows[rowCount][2];
            }
            catch(Exception)
            {
                MessageBox.Show("You are already at the last page");
                rowCount = rowCount - 1;
                txtId.Text = dt.Rows[rowCount][0].ToString();
                txtName.Text = (string)dt.Rows[rowCount][1];
                txtCity.Text = (string)dt.Rows[rowCount][2];
            }
        }

        protected void btnLast_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"server =INBASDPC11337\SQLEXPRESS;Database=dbEmpManagement;Integrated Security =true");
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from tblNewEmployee", con);
            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = cmd;
            DataSet ds = new DataSet();
            da.Fill(ds, "tblNewEmployee");
            DataTable dt = ds.Tables["tblNewEmployee"];
            txtId.Text = dt.Rows[dt.Rows.Count-1][0].ToString();
            txtName.Text = (string)dt.Rows[dt.Rows.Count-1][1];
            txtCity.Text = (string)dt.Rows[dt.Rows.Count-1][2];
        }

    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;

namespace ReflectionsDemo
{
    class ReflectionsDemo
    {
        static void Main(string[] args)
        {
            string testclass = "System.Reflections.PropertyInfo";
            Console.WriteLine("The details of the class {0}",testclass);

            Type MyType = Type.GetType(testclass);

            MemberInfo[] MyMemberInfoArray = MyType.GetMembers();
            //Get the MemeberType method and display the elements

            Console.WriteLine("\nThere are {0} members in {1}",MyMemberInfoArray.GetLength(0),MyType.FullName);

            for(int counter = 0; counter < MyMemberInfoArray.GetLength(0);counter++)
            {
                Console.WriteLine("{0}. {1} Member type - {2}", counter, MyMemberInfoArray[counter].Name, MyMemberInfoArray[counter].MemberType.ToString());
            }
        }
    }
}

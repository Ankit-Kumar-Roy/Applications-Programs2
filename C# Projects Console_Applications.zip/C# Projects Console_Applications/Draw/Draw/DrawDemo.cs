﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Draw
{
    class DrawingObject
    {
        public virtual void Draw()
        {
            Console.WriteLine("Drawing Object");
        }
    }
    class Line : DrawingObject
    {
        public override void Draw()
        {
            Console.WriteLine("Drawing a line");
        }
    }
    class Circle : DrawingObject
    {
        public override void Draw()
        {
            Console.WriteLine("Drawing a Circle");
        }
    }
    class Square : DrawingObject
    {
        public override void Draw()
        {
            Console.WriteLine("Drawing a Square");
        }
    }

    class DrawDemo
    {
        static void Main(string[] args)
        {
            DrawingObject[] obj = new DrawingObject[4];

            obj[0] = new Line();
            obj[1] = new Circle();
            obj[2] = new Square();
            obj[3] = new DrawingObject();

            foreach(DrawingObject o in obj)
            {
                o.Draw();
            }

            Console.Read();
        }
    }
}

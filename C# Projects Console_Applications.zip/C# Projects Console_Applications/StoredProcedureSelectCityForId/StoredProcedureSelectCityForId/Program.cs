﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;

namespace StoredProcedureSelectCityForId
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter the id:");
            int empid = Convert.ToInt32(Console.ReadLine());

            SqlConnection con = new SqlConnection(@"Server=INBASDPC11337\SQLEXPRESS;Database=dbEmpManagement;Integrated Security=true");
            con.Open();

            SqlCommand cmd = new SqlCommand("exec uspSelectCity @id");

            cmd.Connection = con;
            cmd.Parameters.AddWithValue("@id", empid);

           try
            {
                Console.WriteLine("City: {0}", (string)cmd.ExecuteScalar());
            }
            catch (Exception)
            {
                Console.WriteLine("Oops! seems like something happened");
            }
            finally
            {
                con.Close();
            }
            Console.Read();
        }
    }
}

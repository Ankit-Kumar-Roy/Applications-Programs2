﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StaticClass
{
    class StaticClass
    {
        //int n1 = 14; Cannot declare numbers in a static class
        static int n1 = 14;

        public static int sum(int m1, int m2)
        {
            return m1 + m2;
        }
        
        static void Main(string[] args)
        {
            //static obj = new StaticClass(); static class cannot be instantiated

            Console.WriteLine(n1);
            Console.WriteLine(StaticClass.sum(12, 23));
            Console.Read();
        }
    }
}

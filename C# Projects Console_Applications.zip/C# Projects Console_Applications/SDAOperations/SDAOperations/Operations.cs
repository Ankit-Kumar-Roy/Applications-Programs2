﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace SDAOperations
{
    enum Options
    {
        Exit, Display, Insert, Delete, Update
    }
    class Operations
    {
        static void Main(string[] args)
        {
            bool looprepeat = true;
            while (looprepeat)
            {
                ShowMenu();
                int ch = GetInput("Enter your choice: ");
                switch ((Options)ch)
                {
                    case Options.Exit:
                        looprepeat = false;                        
                    break;
                    case Options.Display:
                        DisplayAll();
                    break;
                    case Options.Insert:
                        Insert();
                    break;
                    case Options.Delete:
                        Delete();
                    break;
                    case Options.Update:
                    Update();
                    break;
                    default:
                    Console.WriteLine("Improper input");
                    break;
                }
            }
        }

        private static void Update()
        {
            int employeeId = GetInput("Enter Id:");
            Console.Write("Enter new Name: ");
            string name = Console.ReadLine();
            Console.Write("Enter new City: ");
            string city = Console.ReadLine();
            SqlConnection con = new SqlConnection(@"server =INBASDPC11337\SQLEXPRESS;Database=dbEmpManagement;Integrated Security =true");
            con.Open();
            SqlCommand cmd = new SqlCommand("Update tblNewEmployee set vName = @name, vCity = @city where iEmpId = @id", con);
            cmd.Parameters.AddWithValue("@id", employeeId);
            cmd.Parameters.AddWithValue("@name", name);
            cmd.Parameters.AddWithValue("@city", city);
            SqlDataAdapter da = new SqlDataAdapter();
            da.UpdateCommand = cmd;
            try
            {
                da.UpdateCommand.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                //Console.WriteLine("ID already exists");
                Console.WriteLine(e);
            }
            con.Close();
        }

        private static void Delete()
        {
            int employeeId = GetInput("Enter Id:");
            SqlConnection con = new SqlConnection(@"server =INBASDPC11337\SQLEXPRESS;Database=dbEmpManagement;Integrated Security =true");
            con.Open();
            SqlCommand cmd = new SqlCommand("Delete from tblNewEmployee where iEmpId = @id", con);
            cmd.Parameters.AddWithValue("@id", employeeId);
            SqlDataAdapter da = new SqlDataAdapter();
            da.DeleteCommand = cmd;
            try
            {
                da.DeleteCommand.ExecuteNonQuery();
            }
            catch (Exception)
            {
                Console.WriteLine("ID already exists");
            }
            con.Close();
        }

        private static void DisplayAll()
        {
            SqlConnection con = new SqlConnection(@"server =INBASDPC11337\SQLEXPRESS;Database=dbEmpManagement;Integrated Security =true");
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from tblNewEmployee", con);
            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = cmd;
            DataSet ds = new DataSet();
            da.Fill(ds,"tblNewEmployee");
            foreach (DataTable item in ds.Tables)
            {
                for (int i = 0; i < item.Rows.Count; i++)
                {
                    for (int j = 0; j < item.Columns.Count; j++)
                    {
                        Console.Write(item.Rows[i][j] + " ");
                    }
                    Console.WriteLine();
                }
            }

            con.Close();
            Console.ReadLine();
        }
        private static void Insert()
        {
            int employeeId=GetInput("Enter Id:");
            Console.Write("Enter Name: ");
            string name = Console.ReadLine();
            Console.Write("Enter City: ");
            string city = Console.ReadLine();

            SqlConnection con = new SqlConnection(@"server =INBASDPC11337\SQLEXPRESS;Database=dbEmpManagement;Integrated Security =true");
            con.Open();
            SqlCommand cmd = new SqlCommand("Insert into tblNewEmployee values(@id,@name,@city)",con);
            cmd.Parameters.AddWithValue("@id", employeeId);
            cmd.Parameters.AddWithValue("@name", name);
            cmd.Parameters.AddWithValue("@city", city);
            SqlDataAdapter da = new SqlDataAdapter();
            da.InsertCommand = cmd;
            try
            {
                da.InsertCommand.ExecuteNonQuery();
            }
            catch(Exception)
            {
                Console.WriteLine("Id already exists");
            }
            con.Close();
        }

        private static int GetInput(string msg)
        {
            int ch;
            while (true)
            {
                Console.Write(msg);
                if (int.TryParse(Console.ReadLine(), out ch))
                {
                    return ch;                    
                }
                else
                {
                    Console.WriteLine("Improper input");
                }
            }
        }

        private static void ShowMenu()
        {
            string[] menu = { "1.Display", "2.Insert", "3.Delete", "4.Update", "0. Exit" };
            foreach (var item in menu)
            {
                Console.WriteLine(item);
            }
        }
    }
}

﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QueueDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Queue<object> q = new Queue<object>();
            q.Enqueue("Pankaj");
            q.Enqueue(1);
            q.Enqueue(10.5);
            q.Enqueue(true);
            q.Enqueue('A');
            //Get the number of elements present in the queue
            Console.WriteLine("Count: {0}", q.Count);
            Console.WriteLine();
            //printing all the elements of the queue
            Console.WriteLine("Element in Queue: ");
            foreach (object obj in q)
                Console.WriteLine(obj);
            Console.WriteLine();
            //Returns the ned of the Queue without removing
            Console.WriteLine("End element of queue: {0}", q.Peek());
            Console.WriteLine();
            //Removes and returns the end element of the queue i.e. Dequeue operation
            object TopElement = q.Dequeue();
            Console.WriteLine("Removing end element of Queue = {0}\nNow end element of Queue = {1}\n", TopElement, q.Peek());
            //Determines whether an element present or not in the Queue
            if (q.Contains("Pankaj"))
            {
                Console.WriteLine("Pankaj found");
            }
            else
                Console.WriteLine("Pankaj Lost");
            //copies the queue to a new Array(object)
            Object[] ob = q.ToArray();
            Console.WriteLine();
            foreach(object obj in ob)
            {
                Console.WriteLine(obj);
            }
            //trim the queue
            q.TrimExcess();
            //removes all the elements
            q.Clear();
            Console.WriteLine();
            Console.WriteLine("Count: {0}", q.Count);
            Console.ReadKey();

        }
    }
}

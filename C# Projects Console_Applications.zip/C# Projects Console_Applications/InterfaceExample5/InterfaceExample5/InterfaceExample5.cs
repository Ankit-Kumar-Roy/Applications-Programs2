﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfaceExample5
{
    class InterfaceExample5 : abc
    {
        static void Main(string[] args)
        {
            Console.WriteLine("In main");
            InterfaceExample5 a = new InterfaceExample5();
            xyz();
            Console.Read();
        }
        public static void xyz()
        {
            Console.WriteLine("In xyz");
        }
    }
    interface abc
    {
        static void xyz();// we cannot use static methods inside an interface
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace com.myprogs.AssociateDetails
{
    public class AssociateDetails
    {
        public static void Main()
        {
            string sName;
            int im1, im2, im3, im4, im5;
            float avg;

            Console.WriteLine("Enter Name:");
            sName = Console.ReadLine();
            Console.WriteLine("Enter marks of 5 subjects:");
            im1 = Convert.ToInt32(Console.ReadLine());
            im2 = Convert.ToInt32(Console.ReadLine());
            im3 = Convert.ToInt32(Console.ReadLine());
            im4 = Convert.ToInt32(Console.ReadLine());
            im5 = Convert.ToInt32(Console.ReadLine());

            avg = (im1 + im2 + im3 + im4 + im5) / 5;

            if (avg > 80)
            {
                Console.WriteLine("{0} scored Distinction:",sName);
            }
            else if (avg < 80 && avg > 60)
            {
                Console.WriteLine("{0} scored 1st Class",sName);
            }
            else if (avg < 60 && avg >= 50)
            {
                Console.WriteLine("{0} scored 2nd Class",sName);
            }
            else
            {
                Console.WriteLine("{0} Failed",sName);
            }
            Console.Read();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StackDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            //declaring a stack
            Stack<object> st = new Stack<object>();
            //inserting element into the stack
            st.Push("Pankaj");
            st.Push(1);
            st.Push(10.5);
            st.Push(true);
            st.Push('A');
            //get the number of elements contained in the stack
            Console.WriteLine("Count: {0}", st.Count);
            Console.WriteLine();
            //Printing all the elements of the stack
            Console.WriteLine("Elements in stack: ");
            foreach(object obj in st)
            {
                Console.WriteLine(obj);
            }
            Console.WriteLine();
            //Returns the topmost element of the stack without removing 
            Console.WriteLine("Top most element of the stack is {0}", st.Peek());
            Console.WriteLine();
            //Removes and returns the topmost element of the stack i.e. pop operation
            object TopElement = st.Pop();
            Console.WriteLine("Removing top element of stack = {0}\n Now top element of stack = {1}\n", TopElement, st.Peek());
            //determines whether an element present or not in the stack
            if (st.Contains("Pankaj")) 
                Console.WriteLine("Pankaj found");
            else 
                Console.WriteLine("Pankaj is lost");
            //copies the stack to a new array(object)
            Object[] ob = st.ToArray();
            Console.WriteLine();
            foreach (object obj in ob)
                Console.WriteLine(obj);
            //removes all the elements from stack
            st.Clear();
            Console.WriteLine();
            Console.WriteLine("Count: {0}", st.Count);
            Console.ReadKey();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace com.myprogs.BasicCalc
{
    public class BasicCalc
    {
        public static void Main()
        {
            int iCh, iNum1, iNum2;
            do
            {
                Console.WriteLine();
                Console.WriteLine("Press 1 for Addition");
                Console.WriteLine("Press 2 for Subtraction");
                Console.WriteLine("Press 3 for Multiplication");
                Console.WriteLine("Press 4 for Division");
                Console.WriteLine("Press 0 to exit");
                iCh = Convert.ToInt32(Console.ReadLine());
                if(iCh==0)
                {
                    Environment.Exit(0);
                }
                Console.WriteLine("Enter two numbers:");
                iNum1 = Convert.ToInt32(Console.ReadLine());
                iNum2 = Convert.ToInt32(Console.ReadLine());
                switch (iCh)
                {
                    case 1://Addition
                        {
                            Console.WriteLine("Sum is {0}",iNum1 + iNum2);
                            break;
                        }
                    case 2://Subtraction
                        {
                            Console.WriteLine("Difference is {0}",iNum1 - iNum2);
                            break;
                        }
                    case 3://Multiplication
                        {
                            Console.WriteLine("Product is {0}", iNum1 * iNum2);
                            break;
                        }
                    case 4://Division
                        {
                            try
                            {
                                Console.WriteLine("Quotient is {0}", iNum1 / iNum2);
                                Console.WriteLine("Remainder is {0}", iNum1 % iNum2);
                                break;
                            }
                            catch
                            {
                                Console.WriteLine("Divison by zero is not possible");
                                break;
                            }
                        }
                    default:
                        {
                            Console.WriteLine("Improper input");
                            break;
                        }
                }
            }while(true);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrivateConstructor
{
    public class first
    {
        private first() //Declaring a private constructor
        {

        }

        public static int a;
        public static int disp()
        {
            return ++a;
        }
    }
    class PrivateConstructor
    {
        static void Main(string[] args)
        {
            //first f1 = new first();
            first.a = 100;
            first.disp();

            Console.WriteLine(first.a);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfaceExample3
{
    class InterfaceExample3
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello Interfaces");
        }
    }
    interface abc
    {
        void xyz() // interface cannot have a definition
        {
            Console.WriteLine("In xyz");
        }
    }
    interface cde
    {
        void xyz(); 
    }
    class Inheritor : cde //error since this class is not implementing xyz();
    {

    }
}

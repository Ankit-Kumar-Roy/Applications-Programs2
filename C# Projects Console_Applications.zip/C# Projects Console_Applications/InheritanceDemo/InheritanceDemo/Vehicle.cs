﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceDemo
{
    class Vehicle
    {
        private int weight;
        private int topSpeed;
        private double price;

        public Vehicle()
        {

        }

        public Vehicle(int wt, int speed, double vprice)
        {
	        weight = wt;
	        topSpeed= speed;
	        price = vprice;
        }
        
        public int getWeight()
        {
	        return weight;
        }
        
        public int getTopSpeed()
        {
	        return topSpeed;
        }

        public double getPrice()
        {
	        return price;
        }

        public virtual void print()
        {
	        Console.WriteLine("Weight {0} kg",weight);
	        Console.WriteLine("Top Speed {0} kg",topSpeed);
	        Console.WriteLine("Price {0} kg",price);
        }
    }
    class Car : Vehicle
    {
        private int numberCylinders;
	    private int horsepower;
        private int displacement;

        public Car()
        {

        }

        public Car(int wt, int speed, double price, int numCylinders, int hspower, int dispnt) :base(wt, speed, price)
        {
	        numberCylinders = numCylinders;
	        horsepower = hspower;
            displacement = dispnt;
        }

        public int getNumberCylinders()
        {
	        return numberCylinders;
        }

        public int getHorsepower()
        {
	        return horsepower;
        }   

        public int getDisplacement()
        {
	        return displacement;
        }

        public override void print()
        {
	        base.print();
	        Console.WriteLine("Cylinders: {0}", numberCylinders);
            Console.WriteLine("Horsepower: {0}", horsepower);
	        Console.WriteLine("Displacement: {0} cubic cm", displacement);
        }
    }

    class myCar
    {
        public static void Main(string[] args)
        {
	        Vehicle objVehicle = new Vehicle(15000,120,30000.00);
	        Console.Write("A Vehicle:");
	        objVehicle.print();

	        Console.WriteLine("");
	        Car objCar = new Car(3500,100,12000,6,120,300);
	
	        Console.Write("A Car:");
	        objCar.print();
	        Console.WriteLine("");
            Console.Read();
        }
    }
}



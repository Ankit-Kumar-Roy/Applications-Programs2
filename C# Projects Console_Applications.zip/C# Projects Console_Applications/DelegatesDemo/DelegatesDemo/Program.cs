﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegatesDemo
{
    class Program
    {
        delegate void SimpleDelegate(string s);
        static void Main(string[] args)
        {
            //checking delegate object

            SimpleDelegate del = new SimpleDelegate(displaymessage);

            //invoking function through delegate

            del("Simple delegate");
            Console.Read();
        }
        static void displaymessage(string s)
        {
            Console.Write(s);
        }
    }
}

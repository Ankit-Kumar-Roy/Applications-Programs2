﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace com.myprogs.basic
{
    public class Sum
    {
        static void Main()
        {
            int iNum1, iNum2, iSum;

            Console.WriteLine("Enter two variables:");

            iNum1 = Convert.ToInt32(Console.ReadLine());
            iNum2 = Convert.ToInt32(Console.ReadLine());

            iSum = iNum1 + iNum2;
            Console.WriteLine("The sum is {0}", iSum);
            Console.Read();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication2
{
    class Sample
    {
        public virtual void m1(int i)
        {
            Console.Write(i);
        }
    }
    class Sample1 : Sample
    {
        public override void m1(int i)
        {
            Console.Write(i * 2);
        }
        public void m1(char c)
        {
            Console.WriteLine(c);
        }
    }
    class OverloadOverride
    {
        static void Main(string[] args)
        {
            Sample s = new Sample();
            s.m1(10);
            Sample1 s1 = new Sample1();
            s1.m1(20);
            s1.m1('a');
            Console.Read();
        }
    }
}

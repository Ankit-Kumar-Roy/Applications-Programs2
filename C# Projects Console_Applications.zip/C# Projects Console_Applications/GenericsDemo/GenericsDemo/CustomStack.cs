﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericsDemo
{
    class CustomStack //Non generic implementation of listing
    {
            const int size = 10;
            private object[] register;

            private int count = 0;
            private CustomStack()
            {
                register = new object[size];
            }
            public void Push(object x)
            {
                if(count < size)
                {
                    register[count++] = x;
                }//count == size
            }
            public object Pop()
            {
                return register[--count];
            }
        
            static void Main(string[] args)
            {
                CustomStack intStack = new CustomStack();
                intStack.Push(10);
                int i = (int)intStack.Pop();
                Console.WriteLine(i);
                Console.Read();                
            }
    }
}

﻿using System;
using System.Collections
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HashTableDemo
{
    class HashTableDemo
    {
        static void Main(string[] args)
        {
            Hashtable country = new Hashtable();

            country["India"] = 1;
            country["China"] = 2;
            country["Russia"] = 3;
            country["Brazil"] = 4;

            //country[100] = 1;
            //country[101] = 2;
            //country[102] = 3;

            //we can add duplicate elements but it will not display dupliacte values
            //country[103] = 4;
            //country[103] = 4;

            //DictionaryEntry class provides access to key and value

            foreach(DictionaryEntry element in country)
            {
                string name = (string)element.Key;
                int ranking = (int)element.Value;
                Console.WriteLine("Name: {0}, Rank: {1}",name,ranking);
            }
        }
    }
}

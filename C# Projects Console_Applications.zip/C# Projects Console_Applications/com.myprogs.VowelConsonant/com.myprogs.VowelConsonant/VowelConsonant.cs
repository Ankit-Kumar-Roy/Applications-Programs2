﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace com.myprogs.VowelConsonant
{
    public class VowelConsonant
    {
        public static void Main()
        {
            Console.WriteLine("Enter an alphabet:");
            char c = (char)Console.Read();

            if (Char.IsLetter(c))
            {
                c = Char.ToUpper(c);
                switch (c)
                {
                    case 'A':                        
                    case 'E':                        
                    case 'I':                        
                    case 'O':
                    case 'U':
                        {
                            Console.WriteLine("Vowel");
                            Console.Read();
                            break;
                        }
                    default:
                        {
                            Console.WriteLine("Consonant");
                            Console.Read();
                            break;
                        }
                }
            }
            else
            {
                Console.WriteLine("Improper Input");
            }
        }
    }
}

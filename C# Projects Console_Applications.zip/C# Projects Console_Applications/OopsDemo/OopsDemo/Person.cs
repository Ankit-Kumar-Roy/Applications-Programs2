﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OopsDemo
{
    class Person
    {
        private string myName;
        private int myAge;
        private char mySex;

        public Person()//Default constructor
        {

        }

        public Person(string name, int age, char sex)//Parameterized constructor
        {
            myName = name;
            myAge = age;
            mySex = sex;
        }

        public string Name
        {
            get//Accessors
            {
                return myName;
            }
            set//Mutators
            {
                myName = value;
            }
        }

        public int Age
        {
            get
            {
                return myAge;
            }
            set
            {
                myAge = value;
            }
        }

        public char Sex
        {
            get
            {
                return mySex;
            }
            set
            {
                mySex = value;
            }
        }

        public override string ToString()
        {
            return "Name: " + Name + " Age: " + Age + " Sex: " + Sex;
        }

        public override bool Equals(object o)
        {
            if ((myName == ((Person)o).myName) && (myAge == ((Person)o).myAge) && (mySex == ((Person)o).mySex))
            {
                return true;
            }
            else return false;
        }

        static void Main(string[] args)
        {
            Person p1 = new Person();
            p1.Name = "Joe";
            p1.Age = 99;
            p1.Sex = 'm';

            Console.WriteLine("Person Details {0}", p1.ToString());

            Person p2 = new Person();
            p2.Name = "Jane";
            p2.Age = 31;
            p2.Sex = 'f';

            Console.WriteLine("Person Details {0}", p2);

            Person p3 = new Person();
            p3.Name = "Jane";
            p3.Age = 31;
            p3.Sex = 'f';

            Console.WriteLine("Person Details {0}", p2);

            bool same = p2.Equals(p3);
            Console.WriteLine("Same Person:" + same);

            //making use of parameterized constructor
            Person p4 = new Person("Otto", 42, 'm');
            Console.WriteLine("Person details" + p4.myName);
            Console.WriteLine("Person details" + p4.mySex);

            //Array of persons
            Person[] pmany = new Person[2];
            pmany[0] = new Person("Carl", 23, 'm');
            pmany[1] = new Person("Ola", 7, 'f');

            Console.WriteLine("Name of person[0]" + pmany[0]);
            Console.WriteLine("Name of person[0]" + pmany[0].myName);
            Console.WriteLine("Sex of the person[1]" + pmany[0].mySex);
            Console.Read();
        }
    }
}

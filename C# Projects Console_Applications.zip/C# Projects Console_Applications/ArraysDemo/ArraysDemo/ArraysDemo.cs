﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArraysDemo
{
    public class ArraysDemo
    {
        public static void Main()
        {

            //Declaring an array
            int[] mark;
            mark = new int[2];

            //Assigning elements
            mark[0] = 10;
            mark[1] = 20;

            //Defining at the time of declaring
            int[] mark1 = new int[5];

            //Initializing at the time of declaring
            int[] mark2 = { 10, 60, 20, 50, 30 };

            //Printing an array using for loop
            Console.WriteLine("The 'mark2' array is:");
            for (int i = 0; i < mark2.Length; i++)
            {
                Console.Write("{0} ", mark2[i]);
            }
            //Sorting an array
            Array.Sort(mark2);
            Console.WriteLine("\n\nThe sorted 'mark2' array is:");
            for (int i = 0; i < mark2.Length; i++)
            {
                Console.Write("{0} ", mark2[i]);
            }

            //Binary Search in an array
            int pos = Array.BinarySearch(mark2, 30);
            Console.WriteLine("\n\nElement '30' found in Index {0}, Position {1}", pos,pos+1);

            //Reversing an array
            Array.Reverse(mark2);
            Console.WriteLine("\nThe reverse of 'mark2' array is:");
            foreach (int i in mark2)
            {
                Console.Write("{0} ",i);
            }

            //Copying an array
            Array.Copy(mark2, mark1, 3);
            Console.WriteLine("\n\nThe 'mark1' array copied from 'mark2' array is:");
            foreach (int i in mark1)
            {
                Console.Write("{0} ",i);
            }

            //Clearing an array
            Array.Clear(mark1, 0, 2);
            Console.WriteLine("\n\nThe cleared 'mark1' array is:");
            foreach (int i in mark1)
            {
                Console.Write("{0} ", i);
            }

            //Cloning an array
            int[] cloneMark2 = (int[])mark2.Clone();
            Console.WriteLine("\n\nThe cloned 'mark2' array is:");
            foreach (int i in cloneMark2)
            {
                Console.Write("{0} ", i);
            }
            Console.Read();


        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace com.myprogs.NaturalNumbers
{
    public class NaturalNumbers
    {
        public static void Main()
        {
            int iUpperBound;

            Console.WriteLine("Enter the upperbound:");
            iUpperBound = Convert.ToInt32(Console.ReadLine());

            for (int i = 1; i <= iUpperBound; i++)
            {
                Console.Write(i + " ");
            }
            Console.Read();
        }
    }
}

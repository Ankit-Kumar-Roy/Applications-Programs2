﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//including namespace

using System.Data.SqlClient;

namespace EmployeeDatabase
{
    class Program
    {
        static void Main(string[] args)
        {
            int iEmpId;
            string sName;
            string sCity;

            Console.Write("Enter the employee details: ");
            iEmpId = Convert.ToInt32(Console.ReadLine());
            sName = Console.ReadLine();
            sCity = Console.ReadLine();

            //Establishing connection

            SqlConnection conn = new SqlConnection(@"server =INBASDPC11337\SQLEXPRESS;Database=dbEmpManagement;Integrated Security =true");

            conn.Open();
            //Creating sqlcommand object to store the insert
            SqlCommand comd = new SqlCommand("Insert into tblNewEmployee values(@ID,@Name,@City)");

            //Set connection property of the command object
            comd.Connection = conn;

            //Set the values for sql parameters
            comd.Parameters.Add("@ID", iEmpId);
            comd.Parameters.Add("@Name", sName);
            comd.Parameters.Add("@City", sCity);

            //To execute the command

            comd.ExecuteNonQuery();
            conn.Close();
        }
    }
}

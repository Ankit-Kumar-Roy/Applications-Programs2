﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SortedListDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            //Sorted list object

            SortedList country = new SortedList();
            country["India"] = 1;
            country["China"] = 2;
            country["Russia"] = 3;
            country["Brazil"] = 4;

            foreach(DictionaryEntry element in country)
            {
                string name = (string)element.Key;
                int ranking = (int)element.Value;
                Console.WriteLine("Name {0}, Ranking {1}", name, ranking);
            }
            Console.Read();
        }
    }
}

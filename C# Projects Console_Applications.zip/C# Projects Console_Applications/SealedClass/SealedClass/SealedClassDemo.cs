﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SealedClass
{
    sealed class Seal
    {
        int val;
        Seal()
        {
            
        }
        /*public int Val
        {
            get
            {
                return val;
            }
            set
            {
                val = value;
            }
        }*/
    }
    class SealedClassDemo
    {
        static void Main(string[] args)
        {
            Seal objSeal = new Seal();
        }
    }
}

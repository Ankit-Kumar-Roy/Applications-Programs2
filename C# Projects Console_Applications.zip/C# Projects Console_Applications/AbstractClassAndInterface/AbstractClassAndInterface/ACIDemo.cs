﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractClassAndInterface
{
    interface IErase
    {
        void Erase();
    }
    abstract class Shape
    {
        protected int NoOfPoints; //accessible to the class and the derived class

        public Shape()
        {
            Console.WriteLine("Constructor of base class");
        }

        //Implementation

        public virtual void M1()
        {
            Console.WriteLine("Implemented M1()");
        }

        //Declaration of method

        public abstract void Draw();
        public abstract void Move();
        public abstract int Area();
    }
    //Sealed class cannot be subclassed

    sealed class Square : Shape,IErase
    {
        public void Erase()
        {
            Console.WriteLine("Erase the shape");
        }
        public Square(int nopt)
        {
            this.NoOfPoints = nopt;
        }
        public override void Draw()
        {
            Console.WriteLine("Drawing a sqare with " + this.NoOfPoints.ToString());
        }
        public override void Move()
        {
            Console.WriteLine("Moving a square");
        }
        public override int Area()
        {
            return 8;
        }
        public override void M1()
        {
            Console.WriteLine("Modified in the derived M1()");
        }
    }

    class ACIDemo
    {
        static void Main(string[] args)
        {
            Square objSquare = new Square(4);
            objSquare.Draw();
            objSquare.Move();
            objSquare.Erase();
            objSquare.M1();

            Console.Read();
        }
    }
}

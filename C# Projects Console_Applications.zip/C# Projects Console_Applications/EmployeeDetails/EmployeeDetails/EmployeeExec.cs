﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace EmployeeDetails
{
    class Employee
    {
        private string id;
        private string name;
        private int age;
        private char sex;        
        private string designation;
        private string address;

        public string Id
        {
            get
            {
                return id;
            }
            set
            {
                id = value;
            }
        }
        public string Name
        {
            get
            {
                return name;
            }
            set
            {
                name = value;
            }
        }
        public int Age
        {
            get
            {
                return age;
            }
            set
            {
                age = value;
            }
        }
        public char Sex
        {
            get
            {
                return sex;
            }
            set
            {
                sex = value;
            }
        }
        public string Designation
        {
            get
            {
                return designation;
            }
            set
            {
                designation = value;
            }
        }
        public string Address
        {
            get
            {
                return address;
            }
            set
            {
                address = value;
            }
        }
    }
    
    class EmployeeExec
    {
        static object[] Insert(Employee e, List<object[]> li)
        {            
            
            object[] list = new object[6];            
                        
            Console.Write("\nEnter ID: ");
        top:
            e.Id = Console.ReadLine();
            if (IsUnique(e.Id, li))
            {
                list[0] = e.Id;
            }
            else
            {
                Console.Write("\nID already exists\nEnter something else: ");
                goto top;
            }
            
            Console.Write("Enter Name: ");
            e.Name = Console.ReadLine();
            list[1] = e.Name;
            
            Console.Write("Enter Age: ");
            e.Age = Convert.ToInt32(Console.ReadLine());
            list[2] = e.Age;
            
            Console.Write("Enter Sex: ");
            e.Sex = Console.ReadKey().KeyChar;
            list[3] = char.ToUpper(e.Sex);
            
            Console.Write("\nEnter Designation: ");
            e.Designation = Console.ReadLine();
            list[4] = e.Designation;
            
            Console.Write("Enter Address: ");
            e.Address = Console.ReadLine();
            list[5] = e.Address;

            Console.WriteLine("\nInsertion Successful!\n");
                        
            return list;
        }

        static void Update(List<object[]> li)
        {
            int i;
            
            Console.Write("Enter the Employee ID whose record you want to update: ");
        top:
            string s = Console.ReadLine();
            if(IsUnique(s,li))
            {
                Console.Write("\nThis ID doesn't exist,\nPlease try another ID: ");
                goto top;
            }
            else
            for (i = 0; i < li.ToArray<object>().Length; i++)
            {
                if (li[i][0].Equals(s))
                {
                    do
                    {
                        Console.WriteLine("\nWhat do you want to do?");
                        Console.WriteLine("Press 1 to Change name\nPress 2 to Update age\nPress 3 to Change sex\nPress 4 to Change designation\nPress 5 to Change Address\nOr Press 0 to Abort Updation");
                        Console.Write("\nEnter your choice: ");
                        string ch = Console.ReadLine();
                        switch(ch)
                        {
                            case "1":
                                {
                                    Console.Write("Enter a new value for Name: ");
                                    li[i][1] = Console.ReadLine();
                                    Console.WriteLine("\nName updated");
                                    break;
                                }
                            case "2":
                                {
                                    Console.Write("Enter a new value for Age: ");
                                    li[i][2] = Console.ReadLine();
                                    Console.WriteLine("\nAge updated");
                                    break;
                                }
                            case "3":
                                {
                                    Console.Write("Enter a new value for Sex: ");
                                    li[i][3] = Console.ReadLine();
                                    Console.WriteLine("\nSex updated");
                                    break;
                                }
                            case "4":
                                {
                                    Console.Write("Enter a new value for Designation: ");
                                    li[i][4] = Console.ReadLine();
                                    Console.WriteLine("\nDesignation updated");
                                    break;
                                }
                            case "5":
                                {
                                    Console.Write("Enter a new value for Address: ");
                                    li[i][5] = Console.ReadLine();
                                    Console.WriteLine("\nAddress updated");
                                    break;
                                }
                            case "0":
                                {
                                    goto end;
                                }
                            default:
                                {
                                    Console.WriteLine("Wrong choice");
                                    break;
                                }
                        }
                    } while (true);
                end:
                    Console.Write("");
                }
            }   
        }

        static void Delete(List<object[]> li)
        {
            int i;
            Console.Write("\nEnter the Employee ID whose record you want to delete: ");
        top:
            string s = Console.ReadLine();
            for (i = 0; i < li.ToArray<object>().Length; i++)
            {
                if(li[i][0].Equals(s))
                {
                    break;   
                }
            }
            if (!IsUnique(s, li))
            {
                li.Remove(li[i]);
                Console.WriteLine("\nRecord deleted!");
            }
            else
            {
                Console.Write("ID doesn't exist,\nEnter another ID: ");
                goto top;
            }           
        }

        static void Display(List<object[]> li)
        {
            Console.WriteLine("Available records:\n");
            Console.WriteLine("ID | Name | Age | Sex | Designation | Address |");
            foreach (object[] i in li)
            {
                foreach (object j in i)
                {
                    Console.Write(j + " | ");
                }
                Console.WriteLine();
            }
        }

        static bool IsUnique(string s, List<object[]> li)
        {
            for (int i = 0; i < li.ToArray<object>().Length; i++)
            {
                if (li[i][0].Equals(s))
                {
                    return false;
                }
            }
            return true;
        }
        
        static void Main(string[] args)
        {
            
            Employee emp = new Employee();
            List<object[]> storagelist = new List<object[]>();
            do
            {                                              
                Console.WriteLine("\nWhat do you want to do now?\n");
                Console.WriteLine("Enter 1 for Insertion");
                Console.WriteLine("Enter 2 for Updation");
                Console.WriteLine("Enter 3 for Deletion");
                Console.WriteLine("Enter 4 for Display");
                Console.WriteLine("Enter 0 to Exit");
                Console.Write("\nEnter your choice: ");
                string ch = Console.ReadLine();
                switch(ch)
                {
                    case "1":
                        {
                            storagelist.Add(Insert(emp,storagelist));
                            Display(storagelist);
                            break;
                        }
                    case "2":
                        {
                            Update(storagelist);
                            break;
                        }
                    case "3":
                        {                           
                            Delete(storagelist);                            
                            Display(storagelist);
                            break;
                        }
                    case "4":
                        {
                            Display(storagelist);
                            break;
                        }
                    case "0":
                        {
                            Environment.Exit(0);
                            break;
                        }
                    default:
                        {
                            Console.WriteLine("Wrong choice:");
                            break;
                        }
                }
            } while (true);
        }
    }
}

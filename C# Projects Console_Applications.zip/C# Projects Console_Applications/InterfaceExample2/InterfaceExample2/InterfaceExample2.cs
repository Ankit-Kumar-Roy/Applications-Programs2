﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfaceExample2
{
    class InterfaceExample2
    {
        static void Main(string[] args)
        {
        }
    }
    interface abc// interface cannot have properties
    {
        int x
        {
            set;
            get;
        }
    }
}

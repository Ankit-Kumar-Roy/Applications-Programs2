﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MatAdd
{
    public class MatAdd
    {
        public static void Main()
        {
            //Declaring the 2d arrays
            int[,] mat1 = new int[2, 2];
            int[,] mat2 = new int[2, 2];
            int[,] mat3 = new int[2, 2];

            //Taking inputs for the first array
            Console.WriteLine("Enter the elements of first matrix:");
            for (int i = 0; i < mat1.GetLength(0); i++)
            {
                for (int j = 0; j < mat1.GetLength(1); j++)
                {
                    mat1[i, j] = Convert.ToInt32(Console.ReadLine());
                }
            }

            //Taking inputs for the second array
            Console.WriteLine("Enter the elements of second matrix:");
            for (int i = 0; i < mat2.GetLength(0); i++)
            {
                for (int j = 0; j < mat2.GetLength(1); j++)
                {
                    mat2[i, j] = Convert.ToInt32(Console.ReadLine());
                }
            }

            //Adding the two matrices
            for (int i = 0; i < mat1.GetLength(0); i++)
            {
                for (int j = 0; j < mat1.GetLength(1); j++)
                {
                    mat3[i, j] = mat1[i, j] + mat2[i, j];
                }
            }

            //Printing the resultant matrix
            Console.WriteLine("The resultant matrix is:");
            for (int i = 0; i < mat3.GetLength(0); i++)
            {
                for (int j = 0; j < mat3.GetLength(1); j++)
                {
                    Console.Write("{0} ", mat3[i, j]);
                }
                Console.WriteLine();
            }
            Console.Read();
        }
    }
}

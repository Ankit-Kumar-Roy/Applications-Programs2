﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CharArrays
{
    public class CharArrays
    {
        static void Main()
        {
            char[] grade = { 'A', 'B','C','D' };
            foreach(char c in grade)
            {
                Console.WriteLine(c);
            }
            Console.WriteLine(grade.Count());
            Console.Read();
        }
    }
}

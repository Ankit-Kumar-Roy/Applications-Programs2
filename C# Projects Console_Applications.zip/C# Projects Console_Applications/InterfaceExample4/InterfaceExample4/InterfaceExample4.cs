﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfaceExample4
{
    class InterfaceExample4 : IAbc
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello");
        }
        public void xyz()
        {
            Console.WriteLine("In xyz");
        }
    }
    interface IAbc
    {
        public void xyz(); //public cannot be used
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SwitchString
{
    class SwitchString
    {
        static void Main(string[] args)
        {
            Console.Write("Enter he or she:");
            string ch = Console.ReadLine();
            Console.WriteLine(DoSwitch(ch));
            Console.Read();
        }
        public static string DoSwitch(string c)
        {
            switch (c)
            {
                case "he":
                    {
                        return "He is a boy";                        
                    }
                case "she":
                    {
                        return "She is a girl";
                    }
                default:
                    {
                        return "Wrong input";                        
                    }
            }
        }
    }
}

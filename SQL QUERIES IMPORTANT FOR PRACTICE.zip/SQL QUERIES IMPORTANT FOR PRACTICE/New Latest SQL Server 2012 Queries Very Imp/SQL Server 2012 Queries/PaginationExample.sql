/* Example 1 on Pagination using Offset Fetch*/

SELECT ID,Name FROM Employee
 ORDER BY ID ASC
  OFFSET 1 ROWS 
  FETCH NEXT 5 ROWS ONLY
GO
/* Example 2 Lets go through the example create a 
stored procedure which will use the OFFSET and FETCH feature 
of SQL Server 2012 to achieve sql paging while displaying 
results to client machines. 
In this stored procedure we are passing in a page number and 
the number of rows to return. 
These values are then computed to get the correct page and number of rows*/

USE AdventureWorks2008R2
GO
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = 
OBJECT_ID(N'[dbo].[ExampleUsageOfSQLServerDenaliPagingFeature]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[ExampleUsageOfSQLServerDenaliPagingFeature]
GO
CREATE PROCEDURE ExampleUsageOfSQLServerDenaliPagingFeature
 (
  @PageNo INT,
 @RowCountPerPage INT
 )
AS
SELECT
  BusinessEntityID
 ,PersonType
 ,FirstName + ' ' + MiddleName + ' ' + LastName 
FROM Person.Person
 ORDER BY BusinessEntityID
  OFFSET (@PageNo - 1) * @RowCountPerPage ROWS
  FETCH NEXT @RowCountPerPage ROWS ONLY
GO

/* Display Records Between 101 AND 105 BusinessEntityID */
EXECUTE ExampleUsageOfSQLServerDenaliPagingFeature 21, 05
GO

/*Convert functions in sql server 2012
1.) Try_Convert */
/*Example 1 Covert varchar to datetime2*/
SET DATEFORMAT mdy;
SELECT TRY_CONVERT(datetime2, '12/31/2010') AS Result;
GO
/*Example 2 Error when Converting because an integer cannot be casted to xml*/ 

SELECT TRY_CONVERT(xml, 4) AS Result;
GO

/*2.)TRY_PARSE only for converting from string to date/time and number types */
/*Example 1:*/
SELECT TRY_PARSE('Jabberwokkie' AS datetime2 USING 'en-US') AS Result;
/*Example 2:*/
SELECT
    CASE WHEN TRY_PARSE('Aragorn' AS decimal USING 'sr-Latn-CS') IS NULL
        THEN 'True'
        ELSE 'False'
END
AS Result;

/*3.) TRY_CAST Returns a value cast to the specified data type if the cast succeeds; 
    otherwise, returns null*/

/*Example 1 returns cast failed*/
SELECT 
    CASE WHEN TRY_CAST('test' AS float) IS NULL 
    THEN 'Cast failed'
    ELSE 'Cast succeeded'
END AS Result;
GO

/*Example 2 Returns Null */
SET DATEFORMAT dmy;
SELECT TRY_CAST('12/31/2010' AS datetime2) AS Result;
GO
 
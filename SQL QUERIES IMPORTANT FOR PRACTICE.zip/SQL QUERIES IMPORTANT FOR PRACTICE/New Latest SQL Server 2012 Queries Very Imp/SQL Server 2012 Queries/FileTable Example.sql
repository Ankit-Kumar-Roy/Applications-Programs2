select * from DemoFileTable

Update DemoFileTable
set is_readonly = 1
where name='P1.txt'

delete from DemoFileTable
where name='PP1.txt'
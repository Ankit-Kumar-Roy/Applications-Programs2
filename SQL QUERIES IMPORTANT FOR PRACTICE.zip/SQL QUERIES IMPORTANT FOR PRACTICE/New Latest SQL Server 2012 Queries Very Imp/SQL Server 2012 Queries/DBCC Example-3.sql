/*Example 1 : To Find out the Total 
LOG Files and Sizes*/
DBCC SQLPERF(LOGSPACE);
GO
/*Example 2:To Find out log information and status*/
DBCC LOGINFO
/*Example 3:Displays the complete Pages and rows for
all the tables in the current DB*/
DBCC CHECKDB (HRMS1)
/*Example 4:The total number of extents = 8958, 
  used pages = 71022, 
  and reserved pages = 71651 in this 
  database.(number of mixed extents = 102, mixed pages = 803) 
  in this database.*/
DBCC CHECKALLOC(AdventureWorks);
/*Exmaple 5: DBCC SHOW_STATISTICS displays current 
query optimization statistics for a table or indexed view. 
uses statistics to estimate the cardinality or 
number of rows in the query result, which enables the 
query optimizer to create a high quality query plan*/
DBCC SHOW_STATISTICS ("Person.Address", AK_Address_rowguid);
GO
/*Example 6: To compress the Database*/
DBCC SHRINKDATABASE ('SampleDB')
/*Example 7: To decreases the size of the data and 
log files in SampleDB database to allow for 10 percent 
free space in the database*/
DBCC SHRINKDATABASE ('SampleDB',10)

/*Example 7: To Compress the Files and File Groups*/
ALTER DATABASE AdventureWorks
SET RECOVERY SIMPLE;
GO
-- Shrink the truncated log file to 1 MB.
DBCC SHRINKFILE (AdventureWorks_Log, 0);
GO
-- Reset the database recovery model.
ALTER DATABASE AdventureWorks
SET RECOVERY FULL;
GO

/*To Display the LOG Size,Log Space Used and Status*/

DBCC SQLPERF(LOGSPACE)


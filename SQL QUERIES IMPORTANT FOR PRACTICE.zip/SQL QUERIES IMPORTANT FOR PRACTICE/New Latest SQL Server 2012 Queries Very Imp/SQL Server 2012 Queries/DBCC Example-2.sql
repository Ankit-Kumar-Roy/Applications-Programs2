/*Example on DBCC Commands
1.) DBCC ShowContig : This command is used to 
    scan the table and display the pages and 
    extens and fragemention*/

DBCC ShowContig('CleanTableTest')


/* 2.) To display total pagesize,datapage size,
used pages on a database*/
select * from sys.allocation_units
/*3.) To check the overall Database and tables
with rows spread across the pages*/
DBCC CHECKDB (SampleDB)
/*4.) The total number of extents = 71, 
  used pages = 518, and reserved pages = 549 
  in this database.(number of mixed extents = 25, 
  mixed pages = 181) in this database */
DBCC CHECKALLOC(SampleDB);

/*5.) To check the FileGroups and it's 
Size in a particular DB*/
DBCC CHECKFILEGROUP 
/*Flushes the distributed query 
connection cache used by 
distributed queries against an 
instance of Microsoft SQL Server*/
DBCC FREESESSIONCACHE 
/*Removes all elements from the plan 
cache, removes a specific plan 
from the plan cache by specifying a 
plan handle or SQL handle, 
or removes all cache entries 
associated with a specified resource 
pool */
DBCC FREEPROCCACHE 
/*Defragments indexes of the specified 
  table or view*/
DBCC INDEXDEFRAG 
(AdventureWorks, 'Production.Product', 
PK_Product_ProductID)
/*displays current query optimization 
statistics for a table or indexed 
view. The query optimizer uses 
statistics to estimate the cardinality 
or number of rows in the query result, 
which enables the query optimizer 
to create a high quality query plan*/

DBCC SHOW_STATISTICS
('Person.Address', 
AK_Address_rowguid) WITH HISTOGRAM;
/*Checks the current identity value 
for the specified table in 
SQL Server 2008 and, 
if it is needed, changes the 
identity value. You can also use 
DBCC CHECKIDENT to manually set a 
new current identity value for the 
identity column*/
/*To Reterive the current identity value
of the given table*/
DBCC CHECKIDENT('Emp_121') 
/*Force the Current Identity values to a 
New value*/
DBCC CHECKIDENT ('Emp_121', RESEED, 20);
/*Update the corrects pages and row 
  count inaccuracies in the catalog 
  views which is useful for row and page
  calculations*/
DBCC UPDATEUSAGE (SampleDB,'tbl_Emp01');

/*To Check all enable and disable 
constraints on a table*/
DBCC CHECKCONSTRAINTS 
WITH ALL_CONSTRAINTS;
/*To Check constraints on a specific
table*/
DBCC CHECKCONSTRAINTS(tbl_Emp01);
/*We can use the DBCC INPUTBUFFER 
to start a new connection when the query
is running on another connection*/
CREATE TABLE T10
(Col1 int, Col2 char(3));
GO
DECLARE @i int = 0;
BEGIN TRAN
SET @i = 0;
WHILE (@i < 1000)
BEGIN
INSERT INTO T10 VALUES 
(@i, CAST(@i AS char(3)));
SET @i += 1;
END;
COMMIT TRAN;
--Start new connection #2.
DBCC INPUTBUFFER (53);
/*To Display the Current information 
which is set on the following options*/
DBCC USEROPTIONS;
/*DBCC OPENTRAN display the information of uid,name,
LSN etc..*/
CREATE TABLE T5
(Col1 int, 
Col2 char(3));
GO
BEGIN TRAN
INSERT INTO T5 VALUES (101, 'abc');
GO
DBCC OPENTRAN;
ROLLBACK TRAN;
GO
DROP TABLE T1;
GO

/*Releases all unused cache entries 
from all caches. The SQL Server 
Database Engine proactively cleans 
up unused cache entries in the 
background to make memory available 
for current entries*/
DBCC FREESYSTEMCACHE ('ALL') 
WITH MARK_IN_USE_FOR_REMOVAL;

/*Cleans all cache palns associated with
a resource pool*/
SELECT * FROM sys.dm_resource_governor_resource_pools;
GO
DBCC FREEPROCCACHE ('default');
GO

/*Removes all clean buffers from the buffer pool.*/
DBCC DROPCLEANBUFFERS









/*Sequence in SQL SERVER2012*/
/*Sequence is an independed value 
which can be applied on any table*/
Create table dbo.[test_Sequence]
(
[ID] int,
[Product Name] varchar(50)
)
GO
CREATE SEQUENCE dbo.SequenceID AS int
START WITH 3
INCREMENT BY 1
MINVALUE 1
MAXVALUE 5
CYCLE
NO CACHE;
GO
/*Test and See if sequence is working*/
SELECT next value FOR dbo.SequenceID;

select * from dbo.test_Sequence


/*First Insert With Sequence object*/
INSERT INTO dbo.test_Sequence 
select next value for dbo.SequenceID,'Pens'
GO
/*Second Insert without Sequence*/
INSERT INTO dbo.test_Sequence ([ID],[Product Name]) VALUES (7 , 'MICROSOFT SQL SERVER 2012')

select * from dbo.test_Sequence

/*now we can alter the sequence and restart from 1*/
ALTER SEQUENCE dbo.SequenceID RESTART WITH 1;

select * from sys.sequences 

--How to Use DBCC Clean Table Command*/
/*Example 1- To Clean the Table and reclaim space 
  from dropped variable-length columns in tables*/
/*To Do this we need to do the following Steps*/
/*Step 1: Create a table with some columns*/
CREATE TABLE CleanTableTest
    (FileName nvarchar(4000), 
    DocumentSummary nvarchar(max),
    Document varbinary(max)
    );
GO
/*Step 2 : Insert a few rows into the table
from AdventureWroksDB*/
INSERT INTO CleanTableTest
    SELECT REPLICATE(FileName, 1000), 
           DocumentSummary, 
           Document
    FROM AdventureWorks.Production.Document;
GO
/*Step 3:Verify the current page counts and 
average space used in the dbo.CleanTableTest table*/
DECLARE @db_id SMALLINT;
DECLARE @object_id INT;
SET @db_id = DB_ID(N'SampleDB');
SET @object_id = OBJECT_ID(N'SampleDB.dbo.CleanTableTest');
SELECT alloc_unit_type_desc, 
       page_count, 
       avg_page_space_used_in_percent, 
       record_count
FROM sys.dm_db_index_physical_stats(@db_id, @object_id, NULL, NULL , 'Detailed');
GO
/*Step 4:Drop two variable-length columns from the table*/
ALTER TABLE CleanTableTest
DROP COLUMN FileName, Document;
GO
/*Step 5: Verify the page counts and average space used in the dbo.CleanTableTest 
table Notice that the values have not changed*/
DECLARE @db_id SMALLINT;
DECLARE @object_id INT;
SET @db_id = DB_ID(N'SampleDB');
SET @object_id = OBJECT_ID(N'SampleDB.dbo.CleanTableTest');
SELECT alloc_unit_type_desc, 
       page_count, 
       avg_page_space_used_in_percent, 
       record_count
FROM sys.dm_db_index_physical_stats(@db_id, @object_id, NULL, NULL , 'Detailed');
GO


/*Step 6: Now Run the*/
DBCC CLEANTABLE (SampleDB,'dbo.CleanTableTest');

/*Step 7: Verify the values in the dbo.CleanTableTest table after the DBCC CLEANTABLE command*/

DECLARE @db_id SMALLINT;
DECLARE @object_id INT;
SET @db_id = DB_ID(N'SampleDB');
SET @object_id = OBJECT_ID(N'SampleDB.dbo.CleanTableTest');
SELECT alloc_unit_type_desc, 
       page_count, 
       avg_page_space_used_in_percent, 
       record_count
FROM sys.dm_db_index_physical_stats(@db_id, @object_id, NULL, NULL , 'Detailed');
GO










/*Returns size and fragmentation information for the data and indexes of the specified table or view*/
SELECT * FROM sys.dm_db_index_physical_stats
(DB_ID(N'SampleDBDB'), OBJECT_ID(N'Sparsed'), NULL, NULL , 'DETAILED');
/*This command is used to scan the current DB
and display the pages and extens and fragemention*/
DBCC SHOWCONTIG('tbl_Dept01')
SELECT * FROM sys.dm_db_index_physical_stats('SampleDB','tbl_Emp' , NULL, NULL , 'LIMITED');

/* To display total pagesize,datapage size,
used pages on a database*/
select * from sys.allocation_units
/*To display the rows spread accross
the pages in a table*/ 
DBCC CHECKTABLE ('tbl_Emp01')
/*To check the overall Database and tables
with rows spread across the pages*/
DBCC CHECKDB (SampleDB)
/*The total number of extents = 8958, 
  used pages = 71022, 
  and reserved pages = 71651 in this 
  database.(number of mixed extents = 102, mixed pages = 803) 
  in this database.*/
DBCC CHECKALLOC(AdventureWorks);


/*Step 2: Check the Space occupied by the table*/

-- Populate the table with data from the Production.Document table.
-- Verify the current page counts and average space used in the dbo.CleanTableTest table.
DECLARE @db_id SMALLINT;
DECLARE @object_id INT;
SET @db_id = DB_ID(N'HRMS_DB');
SET @object_id = OBJECT_ID(N'HRMS_DB.dbo.CleanTableTest');
SELECT alloc_unit_type_desc, 
       page_count, 
       avg_page_space_used_in_percent, 
       record_count
FROM sys.dm_db_index_physical_stats(@db_id, @object_id, NULL, NULL , 'Detailed');
GO




-- Verify the page counts and average space used in the dbo.CleanTableTest table
-- Notice that the values have not changed.
DECLARE @db_id SMALLINT;
DECLARE @object_id INT;
SET @db_id = DB_ID(N'HRMS_DB');
SET @object_id = OBJECT_ID(N'HRMS_DB.dbo.CleanTableTest');
SELECT alloc_unit_type_desc, 
       page_count, 
       avg_page_space_used_in_percent, 
       record_count
FROM sys.dm_db_index_physical_stats(@db_id, @object_id, NULL, NULL , 'Detailed');
GO
-- Run DBCC CLEANTABLE.
DBCC CLEANTABLE (SampleDB,'CleanTableTest');
GO
-- Verify the values in the dbo.CleanTableTest table after the DBCC CLEANTABLE command.
DECLARE @db_id SMALLINT;
DECLARE @object_id INT;
SET @db_id = DB_ID(N'AdventureWorks2012');
SET @object_id = OBJECT_ID(N'AdventureWorks2012.dbo.CleanTableTest');
SELECT alloc_unit_type_desc, 
       page_count, 
       avg_page_space_used_in_percent, 
       record_count
FROM sys.dm_db_index_physical_stats(@db_id, @object_id, NULL, NULL , 'Detailed');
GO

/*Step 3:drop the columns on the table
and see the space*/
alter table tbl_emp
drop column emp_name
/*Step 4: Now run the below command to see the 
space is reduced*/

DBCC CleanTable(AdventureWorks,'Production.Document', 0)

/*To check the FileGroups and it's 
Size in a particular DB*/
DBCC CHECKFILEGROUP 
/*Flushes the distributed query 
connection cache used by 
distributed queries against an 
instance of Microsoft SQL Server*/
DBCC FREESESSIONCACHE 
/*Removes all elements from the plan 
cache, removes a specific plan 
from the plan cache by specifying a 
plan handle or SQL handle, 
or removes all cache entries 
associated with a specified resource 
pool */
DBCC FREEPROCCACHE 
/*Defragments indexes of the specified 
  table or view*/
DBCC INDEXDEFRAG 
(AdventureWorks, 'Production.Product', 
PK_Product_ProductID)
/*displays current query optimization 
statistics for a table or indexed 
view. The query optimizer uses 
statistics to estimate the cardinality 
or number of rows in the query result, 
which enables the query optimizer 
to create a high quality query plan*/

DBCC SHOW_STATISTICS
('Person.Address', 
AK_Address_rowguid) WITH HISTOGRAM;
/*Checks the current identity value 
for the specified table in 
SQL Server 2008 and, 
if it is needed, changes the 
identity value. You can also use 
DBCC CHECKIDENT to manually set a 
new current identity value for the 
identity column*/
/*To Reterive the current identity value
of the given table*/
DBCC CHECKIDENT('Emp_121') 
/*Force the Current Identity values to a 
New value*/
DBCC CHECKIDENT ('Emp_121', RESEED, 20);
/*Update the corrects pages and row 
  count inaccuracies in the catalog 
  views which is useful for row and page
  calculations*/
DBCC UPDATEUSAGE (SampleDB,'tbl_Emp01');

/*To Check all enable and disable 
constraints on a table*/
DBCC CHECKCONSTRAINTS 
WITH ALL_CONSTRAINTS;
/*To Check constraints on a specific
table*/
DBCC CHECKCONSTRAINTS(tbl_Emp01);
/*We can use the DBCC INPUTBUFFER 
to start a new connection when the query
is running on another connection*/
CREATE TABLE T10
(Col1 int, Col2 char(3));
GO
DECLARE @i int = 0;
BEGIN TRAN
SET @i = 0;
WHILE (@i < 1000)
BEGIN
INSERT INTO T10 VALUES 
(@i, CAST(@i AS char(3)));
SET @i += 1;
END;
COMMIT TRAN;
--Start new connection #2.
DBCC INPUTBUFFER (53);
/*To Display the Current information 
which is set on the following options*/
DBCC USEROPTIONS;
/*DBCC OPENTRAN display the information of uid,name,
LSN etc..*/
CREATE TABLE T5
(Col1 int, 
Col2 char(3));
GO
BEGIN TRAN
INSERT INTO T5 VALUES (101, 'abc');
GO
DBCC OPENTRAN;
ROLLBACK TRAN;
GO
DROP TABLE T1;
GO

/*Releases all unused cache entries 
from all caches. The SQL Server 
Database Engine proactively cleans 
up unused cache entries in the 
background to make memory available 
for current entries*/
DBCC FREESYSTEMCACHE ('ALL') 
WITH MARK_IN_USE_FOR_REMOVAL;

/*Cleans all cache palns associated with
a resource pool*/
SELECT * FROM sys.dm_resource_governor_resource_pools;
GO
DBCC FREEPROCCACHE ('default');
GO

/*Removes all clean buffers from the buffer pool.*/
DBCC DROPCLEANBUFFERS









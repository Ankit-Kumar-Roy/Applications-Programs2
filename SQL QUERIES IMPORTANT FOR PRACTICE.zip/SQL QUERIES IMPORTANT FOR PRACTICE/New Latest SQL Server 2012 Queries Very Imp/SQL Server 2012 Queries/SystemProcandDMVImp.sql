/*All the System Stored Procedures and DMV
(Dynamic Management Views)*/
/*Provides information about current 
users, sessions, and processes in an 
instance of the Microsoft SQL Server 
Database Engine*/
sp_who
/*Displays as as above but with 
SPID,CPU TIME,DISKIO*/
sp_who2
/*Returns information about currently 
active lock manager resources.Each row represents 
a currently active request to the lock 
manager for a lock that has been 
granted or is waiting to be granted*/
select * from sys.dm_tran_locks 
/*Displays all the information 
of transcation*/
select * from sys.dm_tran_active_transactions 
/*Returns a single row that displays 
the state information of the 
transaction in the current session*/
select * from sys.dm_tran_current_transaction

/*Returns information about all the 
waits encountered by threads that 
executed*/ 
select * from sys.dm_os_wait_stats 

/*Returns information about the wait 
queue of tasks that are waiting on 
some resource*/
select * from sys.dm_os_waiting_tasks 
/*Displays the File and File Group Information along with
the physical path*/
select * from sys.database_files  
/*Returns O/S Memory information*/
select * from sys.dm_os_sys_memory
/*Returns a miscellaneous set of useful 
information about the computer, and 
about the resources available to 
and consumed by SQL Server*/
select * from sys.dm_os_sys_info
/*Display's Memoray releated information*/
select * from sys.dm_os_process_memory
/*Returns information about all latch 
waits organized by class*/
select * from sys.dm_os_latch_stats   
/*The Following Commands display the 
referenced and referincing columns*/
USE AdventureWorks
GO
CREATE TABLE dbo.Table1 (a int, b int, c AS a + b);
GO
SELECT referenced_schema_name AS schema_name,
    referenced_entity_name AS table_name,
    referenced_minor_name AS referenced_column,
    COALESCE(COL_NAME(OBJECT_ID(N'dbo.Table1'),referencing_minor_id), 'N/A') AS referencing_column_name
FROM sys.dm_sql_referenced_entities ('dbo.Table1', 'OBJECT');
GO
/*Returns a row for each pending I/O 
request in SQL Server.*/
select * from sys.dm_io_pending_io_requests
/*Returns information about database 
table columns that are missing an 
index, excluding spatial indexes*/
USE AdventureWorks
GO
SELECT City, StateProvinceID, PostalCode
FROM Person.Address
WHERE StateProvinceID = 9;
go


SELECT mig.*, statement AS table_name,
    column_id, column_name, column_usage
FROM sys.dm_db_missing_index_details AS mid
CROSS APPLY sys.dm_db_missing_index_columns (mid.index_handle)
INNER JOIN sys.dm_db_missing_index_groups AS mig ON mig.index_handle = mid.index_handle
ORDER BY mig.index_group_handle, mig.index_handle, column_id;
GO
/*Display the Index Usage statics*/
select * from sys.dm_db_index_usage_stats 
SELECT * FROM sys.dm_db_index_physical_stats
(DB_ID(N'AdevntureWorks'), OBJECT_ID('Person.Address'), NULL, NULL , 'DETAILED');
/*Returns space usage information for each file in the database*/
select * from sys.dm_db_file_space_usage 
/*Returns page and row-count information for every partition in the current database*/
select * from sys.dm_db_partition_stats 
/*Returns page allocation and deallocation activity by task for the database*/
select * from sys.dm_db_task_space_usage
/* Due to Delete operations from a table or 
update operations that cause a row to 
move can immediately free up space on a 
page by removing references to the row*/ 
USE master
GO
EXEC sp_clean_db_free_space 
@dbname = N'HRMS_DB' ;
/*Returns the Complete Data types list*/
USE master;
GO
EXEC sp_datatype_info
GO
/*Sets option values for user-defined 
tables. sp_tableoption can be used to 
control the in-row behavior of tables 
with varchar(max), nvarchar(max), varbinary(max), 
xml, text, ntext, image, or 
large user-defined type columns*/
USE AdventureWorks
GO
EXEC sp_tableoption 'HumanResources.JobCandidate', 'large value types out of row', 1;
/*Removes all the extra information on the 
primary file of the database*/
USE Master
GO
EXEC sp_clean_db_file_free_space 
@dbname = N'AdventureWorks', @fileid = 1 ;
/*Display's all the locks */
exec sp_lock
/*Release all the locks on the current application*/
USE AdventureWorks;
GO
EXEC sp_getapplock @DbPrincipal = 'dbo', @Resource = 'Form1', 
     @LockMode = 'Shared';
EXEC sp_releaseapplock @DbPrincipal = 'dbo', @Resource = 'Form1';
GO
/*Display's all the depends on the table object*/
USE AdventureWorks
GO
EXEC sp_depends @objname = N'Sales.Customer' ;
/*To set the locks on page-level or row-level
based on the condition generally used
by DBA*/
sp_indexoption 
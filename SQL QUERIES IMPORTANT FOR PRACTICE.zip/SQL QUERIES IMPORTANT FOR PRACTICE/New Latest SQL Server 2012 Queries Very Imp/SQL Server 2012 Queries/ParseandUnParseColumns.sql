/*Example -1  Creating a Table without sparse columns */
CREATE TABLE UnSparsed(ID INT IDENTITY(1,1),
FirstCol INT,
SecondCol VARCHAR(100),
ThirdCol SmallDateTime)
GO
/*Example -2 Creating a Table With Parse columns */
CREATE TABLE Sparsed(ID INT IDENTITY(1,1),
FirstCol INT SPARSE,
SecondCol VARCHAR(100) SPARSE,
ThirdCol SmallDateTime SPARSE)
GO

delete from Sparsed 
delete from UnSparsed
/*Insert data into both the table using 
loop*/
DECLARE @idx INT = 0
WHILE @idx < 50000
BEGIN
INSERT INTO UnSparsed VALUES (1,NULL, NULL)
INSERT INTO Sparsed VALUES (1, NULL, NULL)
SET @idx+=1
END
/*Check the space used by both columns with sparse and 
with out parse columns */
sp_spaceused 'UnSparsed'
go
sp_spaceused 'Sparsed'
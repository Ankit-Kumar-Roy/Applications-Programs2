--Example on Conversation Methods
--TRY_CAST,TRY_CONVERT,PARSE

--Example 1 first we set the defualt language to english
--and then use the parse method
SET LANGUAGE 'ENGLISH'
select parse('12/16/2010' as datetime2) as result

--Example 2 set the dateformat first to mm/dd/yy
--and then use the try_cast
set DateFormat mdy
select try_cast('12/31/2012' as datetime2) as result

set DateFormat mdy
select TRY_CONVERT(datetime2,'12/31/2012') as result 

select DATEFROMPARTS(2012,12,31) as result


--Example 3 display end of the month date
declare @date1 DATETIME
set @date1 ='02/1/2013'
select EOMONTH(@date1) as result


--Three Programming Constructs Statments
--IIF,CHOOSE, CASE
select CHOOSE(2,'developer','writter','manager','lead','junior')

exec sp_configure filestream_access_level,2
reconfigure
go

create table File_Tb_1 as FileTable
With
(FileTable_Directory='File_Tb_1');

select DB_NAME(database_id),non_transacted_access from sys.database_filestream_options

--Example Page Data Using OFFSET and Fetxh Next
select * from Emp_1
order by Emp_ID
OFFSET 4 ROWS
fetch next 2 ROWS only

create table Emp_01
(
Emp_ID int not null sequence(2,1),
Emp_Name varchar(35)
)

CREATE SEQUENCE DemoSequence
START WITH 1
INCREMENT BY 1;

BEGIN TRAN
SELECT NEXT VALUE FOR dbo.DemoSequence
ROLLBACK TRAN







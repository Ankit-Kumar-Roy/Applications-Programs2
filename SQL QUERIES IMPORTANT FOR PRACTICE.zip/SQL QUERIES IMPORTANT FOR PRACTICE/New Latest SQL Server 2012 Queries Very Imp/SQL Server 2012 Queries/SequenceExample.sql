/* 1.) A sequence is a user-defined schema bound object that 
   generates a sequence of numeric values according to the 
   specification with which the sequence was created. 
   2.) The sequence of numeric values is generated in an ascending or descending order 
      at a defined interval and can be configured to restart (cycle) when exhausted. 
  3.) Sequences, unlike identity columns, are not associated with specific tables

Note :A sequence can be defined as any integer type. The following types are allowed.

tinyint - Range 0 to 255

smallint - Range -32,768 to 32,767

int - Range -2,147,483,648 to 2,147,483,647

bigint - Range -9,223,372,036,854,775,808 to 9,223,372,036,854,775,807

decimal and numeric with a scale of 0.

Any user-defined data type (alias type) that is based on one of the allowed types.*/


/*Example 1 Creating a Sequence Object that increments by 1 value*/

CREATE SEQUENCE CountBy1
    START WITH 1
    INCREMENT BY 1 ;
GO

/*Exmaple 2 Creating a Sequence Object that decrements by 1 value*/
CREATE SEQUENCE CountByNeg1
    START WITH 0
    INCREMENT BY -1 ;
GO

/*Example 3 Creating a sequence that starts with a designated number*/
CREATE SEQUENCE ID_Seq
    START WITH 24329
    INCREMENT BY 1 ;
GO

/* Example 4 Creating a sequence with a specific data type */
CREATE SEQUENCE SmallSeq
    AS smallint ;

/*Example 5 Creating a Sequence with all the paramaters*/
CREATE SEQUENCE DecSeq
    AS decimal(3,0) 
    START WITH 125
    INCREMENT BY 25
    MINVALUE 100
    MAXVALUE 200
    CYCLE /*Property that specifies whether the sequence object should 
	        restart from the minimum value (or maximum for descending sequence objects) 
			or throw an exception when its minimum or maximum value is exceeded. 
			The default cycle option for new sequence objects is NO CYCLE.*/


    CACHE 3; /*Increases performance for applications that use sequence objects by minimizing the number of disk IOs that are required to generate sequence numbers.
	           When created with the CACHE option, an unexpected shutdown (such as a power failure) may result in the 
			   loss of sequence numbers remaining in the cache.*/

 


/*Example 5 Executing a sequqence object*/
SELECT NEXT VALUE FOR DecSeq;

 /* Exmaple 6 Create a Sequence object and increment by 1 value*/

 CREATE SEQUENCE [DBO].[SequenceExample] AS INT
 START WITH 1 
 INCREMENT BY 1 
 GO             

CREATE TABLE dbo.Employee(ID INT,Name VARCHAR(100)) 
GO 
--INSERT RECORDS to the Employee table with Sequence object 
INSERT INTO dbo.Employee VALUES(NEXT VALUE FOR DBO.SequenceExample,'Eric'),  
(NEXT VALUE FOR DBO.SequenceExample,'Rajesh'), 
(NEXT VALUE FOR DBO.SequenceExample,'Samuel') 
-- CHECK THE RECORDS INSERTED IN THE TABLE
SELECT * FROM dbo.Employee WITH(NOLOCK) 

/*Example 7 Associate a sequence object to a table*/
CREATE TABLE dbo.Customer (ID INT DEFAULT(NEXT VALUE FOR DBO.SequenceExample),
Name VARCHAR(100)) 

INSERT INTO dbo.Customer(Name) VALUES('Eric'), ('Samuel') 
-- CHECK THE RECORDS INSERTED IN THE TABLE 
SELECT * FROM dbo.Customer WITH(NOLOCK) 

/*Example Getting Next Sequence Value in A SELECT Statement */  
SELECT (NEXT VALUE FOR DBO.SequenceExample)
AS SequenceValue 
/*Getting a Sequence Next Value into a variable*/
DECLARE @EmpID AS INT = NEXT VALUE FOR DBO.SequenceExample 
SELECT @EmpID AS 'Employee Id'
/*Re-Setting the Sequence Number*/
ALTER SEQUENCE DBO.SequenceExample 
RESTART WITH 1 ; 
--Verify whether sequence number is re-set 
SELECT (NEXT VALUE FOR DBO.SequenceExample)      

/*Example 8 How to get the current values of the sequence*/
SELECT Current_Value  FROM SYS.Sequences  
WHERE name='SequenceExample'

select * from sys.sequences 

/* Limitation and Restrications on sequence object */
CREATE SEQUENCE [DBO].[SequenceExample] AS INT 
START WITH 1  
INCREMENT BY 1 
--Create Employee Table 
CREATE TABLE dbo.Employee
(
ID INT,
Name VARCHAR(100)
) 
-- INSERT RECORDS to the Employee table with Sequence object 
INSERT INTO dbo.Employee VALUES (NEXT VALUE FOR DBO.SequenceExample,'BASAV'),  
(NEXT VALUE FOR DBO.SequenceExample,'SHREE'),  
(NEXT VALUE FOR DBO.SequenceExample,'PRATHAM')

select * from dbo.Employee
--The NEXT VALUE FOR function cannot be used in the following situations:
--1) In a statement using the DISTINCT, UNION, UNION ALL, EXCEPT or INTERSECT operator.

SELECT (NEXT VALUE FOR DBO.SequenceExample) UNION
SELECT (NEXT VALUE FOR DBO.SequenceExample)  
--RESULT:

--Msg 11721, Level 15, State 1, Line 1
--NEXT VALUE FOR function cannot be used directly in a statement that uses a DISTINCT, UNION, UNION ALL, EXCEPT or INTERSECT operator.

--In a statement using the ORDER BY clause unless NEXT VALUE 
--FOR � OVER (ORDER BY �) is used.

SELECT NAME, (NEXT VALUE FOR DBO.SequenceExample) SeqValue FROM dbo.Employee ORDER BY NAMEGO 

--RESULT:
--Msg 11723, Level 15, State 1, Line 1
--NEXT VALUE FOR function cannot be used directly in a statement that contains an ORDER BY clause unless the OVER clause is specified.

--3) In a statement using TOP, OFFSET, or when the ROWCOUNT option is set.


SELECT TOP 10  (NEXT VALUE FOR DBO.SequenceExample)

--RESULT:
--Msg 11739, Level 15, State 1, Line 1
--NEXT VALUE FOR function cannot be used if ROWCOUNT option has been set, or the query contains TOP or OFFSET.

--4) In conditional expressions using CASE, CHOOSE, COALESCE, IIF, ISNULL, or NULLIF.

DECLARE @v INT 
SELECT ISNULL(@v,(NEXT VALUE FOR DBO.SequenceExample))
--RESULT:

--Msg 11741, Level 15, State 1, Line 2
--NEXT VALUE FOR function cannot be used within CASE, CHOOSE, COALESCE, IIF, ISNULL and NULLIF.

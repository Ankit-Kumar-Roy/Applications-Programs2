--Creating a Change Data Capture for tracking the changes made to the rows in the database
--kindly refer to this example
--Along with the follwoing link

--http://www.mssqltips.com/sqlservertip/1474/using-change-data-capture-cdc-in-sql-server-2008/
--http://www.simple-talk.com/sql/learn-sql-server/introduction-to-change-data-capture-(cdc)-in-sql-server-2008/

--There are few steps that has to be followed to enable the cdc(change data capture)
--Step 1: Enable the CDC on the Database
--It is only avaiable in developer,enterprise edition
use sampleDB
go
exec sys.sp_cdc_enable_db


--Step 2: check on which databases CDC is enabled
use master
go
select [name],database_id is_cdc_enabled
from sys.databases
go

--Step 3: Check on which table CDC is enabled

select [name],is_tracked_by_cdc from sys.tables

--Step 3: Enable cdc on a table using the following syntax
--after this step
--Now Go and check the jobs it will create CD_jobs refer to them
use sampleDB
go
exec sys.sp_cdc_enable_table
@source_schema='dbo',
@source_name='Emp_1',
@role_name=NULL
go

--Step 4: Refer to the base table
select * from Emp_1
go

--Step 5: Now go and check the system tables it will create 
--cdc.captured table with the database name
--like [cdc].[dbo_Emp_1_CT] which tracks the changes

select * from [cdc].[dbo_Emp_1_CT]
go


--Step 6: Now insert a new value in the table Emp_1 
insert into Emp_1 values(5,'samuel',7800)

--Step 7: Now run the following query to check the changes made
select * from Emp_1
go
select * from [cdc].[dbo_Emp_1_CT]
go
--For After Update value is 4,Insert 2,Delete 3 pleae see the ouput windows

--if you update the columns with the same values it will not track the changes
--in CDC see the ouput window
update Emp_1 set Emp_Salary=9000
where Emp_ID=5

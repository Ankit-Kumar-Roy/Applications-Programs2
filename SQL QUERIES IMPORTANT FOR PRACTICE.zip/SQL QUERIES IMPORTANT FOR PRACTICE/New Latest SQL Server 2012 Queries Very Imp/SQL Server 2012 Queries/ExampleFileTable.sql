
exec sp_configure filestream_access_level,2
reconfigure
go

create database FileTableDB
on PRIMARY
(name=FileTableDB,
FILENAME='D:\FileTable\FTDB.mdf'),
FILEGROUP FTFG CONTAINS FILESTREAM
(NAME=FileTableFS,
FileName='D:\FileTable\FS')
LOG ON
(Name=FileTableDBLog,
FILENAME='D:\FileTable\FTDB.ldf')
WITH FILESTREAM (NON_TRANSACTED_ACCESS = Full,
DIRECTORY_NAME=N'FileTableDB')
go

use EmpDB
create table FileTableTb as FileTable
With
(FileTable_Directory='FileTableTb_Dir');

select DB_NAME(database_id),non_transacted_access from sys.database_filestream_options

use FileTableDB
Go 
select * from FileTableTb

Update FileTableTb
set is_readonly = 1
where name='P2.txt'

delete from FileTableTb
where name='P2.txt'


  
/*To see the list of pages in the index*/
DBCC INDEXDEFRAG (EMPDB,EMP_1)
/*To-Rebuilt Index*/
DBCC DBREIndex(EMP_1)
/*To Alter Rebuild Index*/
alter index Rebuild Emp_1
/* Example on Fetch and OFFSET Row */
/* It will skip the first 2 rows and starts with 3 row and display
rest of the rows */
Select Emp_ID,Emp_Name,Emp_Sal from Emp01 Order By 
Emp_ID 
OFFSET 2 Rows

/*Example on how to use the paging 
In the Example start with 4th row and display only next 3 rows*/
Select  Emp_ID,Emp_Name,Emp_Sal from Emp01 
Order By Emp_ID 
OFFSET 3 Rows
Fetch Next 3 Rows only

/* Example with Stored Procedure Usage*/
Create Procedure dbo.Sp_ExamplePaging 
@PageNo int, @RecordsPerPage int
AS  
Select Emp_ID,Emp_Name,Emp_Sal 
from Emp01 Order By Emp_ID 
OFFSET (@PageNo-1) * @RecordsPerPage ROWS 
FETCH NEXT @RecordsPerPage ROWS ONLY
/*Execute the Stored Procedure*/
Exec dbo.Sp_ExamplePaging 3,6
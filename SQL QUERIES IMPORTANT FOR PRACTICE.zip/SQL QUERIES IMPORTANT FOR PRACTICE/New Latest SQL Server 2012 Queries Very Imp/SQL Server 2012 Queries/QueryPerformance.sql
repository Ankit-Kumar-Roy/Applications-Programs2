/*To Monitor the Memeoty Status*/
DBCC MEMORYSTATUS
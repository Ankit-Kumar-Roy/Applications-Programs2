/*Using Identity we cannot insert into the 
table column which has been set as identity*/

CREATE TABLE dbo.Tool(
   ID INT IDENTITY NOT NULL PRIMARY KEY, 
   Name VARCHAR(40) NOT NULL
)
GO
-- Inserting values into products table.
INSERT INTO dbo.Tool(Name) VALUES ('Screwdriver')
INSERT INTO dbo.Tool(Name) VALUES ('Hammer')
INSERT INTO dbo.Tool(Name) VALUES ('Saw')
INSERT INTO dbo.Tool(Name) VALUES ('Shovel')
GO

INSERT INTO dbo.Tool (ID, Name) VALUES (3, 'Garden shovel')
GO

/*After we set the Identity Insert On
we can insert the values into the table
for the identity column also*/
SET IDENTITY_INSERT dbo.Tool ON
GO

-- Try to insert an explicit ID value of 5.
INSERT INTO dbo.Tool (ID, Name) VALUES (5, 'Gary')
GO





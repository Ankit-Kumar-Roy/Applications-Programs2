--Configuration Functions
--1.)@@DateFirst
/* The following example sets the 
   first day of the week to 5 
   (Friday), and assumes the current 
   day, Today, to be Saturday. 
   The SELECT statement returns the 
   DATEFIRST value and the number 
   of the current day of the week*/
SET DATEFIRST 5;
SELECT @@DATEFIRST AS 'First Day'
,DATEPART(dw, SYSDATETIME()) AS 'Today';
--2.@@DBTs Returns the Current timestamp 
--of a particular database
select @@DBTS
--3.Set the TEXTSIZE option to the 
-- default size of 4096 bytes.
SET TEXTSIZE 0
SELECT @@TEXTSIZE AS 'Text Size'
SET TEXTSIZE 2048
SELECT @@TEXTSIZE AS 'Text Size'


--4.Change the Max Precision size
SELECT @@MAX_PRECISION AS 'Max Precision'

--5. to display the current user,login
SELECT @@SPID AS 'ID', SYSTEM_USER AS 'Login Name', USER AS 'User Name';
--6.To disaply the total no.of connections to the server
SELECT @@MAX_CONNECTIONS AS 'Max Connections'
--7 to Display total Read and writes on a disk
SELECT @@TOTAL_READ AS 'Reads', @@TOTAL_WRITE 
AS 'Writes', GETDATE() AS 'As of'
--To Display the Column Previlages on a given table
EXEC sp_column_privileges @table_name = 'Employee' 
    ,@table_owner = 'HumanResources'
    ,@table_qualifier = 'AdventureWorks2012'
    ,@column_name = 'SalariedFlag';
--Returns columns inforamation on a particular table

EXEC sp_columns @table_name = N'Department',
   @table_owner = N'HumanResources';
--Returns a list of special columns
EXEC sp_special_columns @table_name = 'Department' 
    ,@table_owner = 'HumanResources';

--Display list of permission like
--insert,select,delete on a given database
--and tables
EXEC sp_table_privileges 
   @table_name = 'Contact%';

--To clean the free space on a 
--particular database
EXEC sp_clean_db_free_space 
@dbname = N'AdventureWorks'


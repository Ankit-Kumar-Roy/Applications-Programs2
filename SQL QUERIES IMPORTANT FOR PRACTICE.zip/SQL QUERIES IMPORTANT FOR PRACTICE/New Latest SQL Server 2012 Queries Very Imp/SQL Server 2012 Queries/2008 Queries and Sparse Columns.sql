
SELECT fld_DeptID,fld_DeptName,
fld_DeptLocation from (VALUES(1,'NNTech','UK' ) )
 AS Dept_001(fld_DeptID,fld_DeptName,fld_DeptLocation)
 

CREATE TABLE Product1
(
ProductID INT NOT NULL PRIMARY KEY,
ProductName NVARCHAR(50) NOT NULL,
Price int SPARSE NULL,
Discount int SPARSE NULL,
ProductInfo XML COLUMN_SET FOR ALL_SPARSE_COLUMNS
)

sp_help Product1
select * from Product1

INSERT INTO Product1
(ProductID,ProductName,Price,Discount)
values(11,'Soaps',NULL,NULL)

select ProductID,ProductName,Price,Discount
from (values(12,'Pens',NULL,NULL))
as Product1(ProductID,ProductName,Price,Discount)

/* DateTime Functions*/
/*Example-1 */
select SYSDATETIMEOFFSET() as sysdatetimeoffset,
SYSDATETIME() as sysdatetime

/*Example 2 On Date,Time,DateTime2,DateTimeOffSet*/

declare @date date,
@time time,
@datetime2 datetime2,
@datetimeoffset datetimeoffset

select @date = getdate(),
@time = sysdatetime(),
@datetime2 = SYSDATETIME(),
@datetimeoffset = SYSDATETIMEOFFSET()
select @date as 'date',@time as 'time',
@datetime2 as 'datetime2',@datetimeoffset as 'datetimeoffset'

/*Example-3 Convert Function*/
select convert(varchar(35), SYSDATETIMEOFFSET(), 121) as datetime_offset,
CONVERT(varchar(30), cast(SYSDATETIMEOFFSET() as datetime2),121) as datetime2


CREATE TABLE dbo.Employees
(
  empid   INT NOT NULL,
  hid     HIERARCHYID NOT NULL,
  lvl AS hid.GetLevel() PERSISTED,
  empname VARCHAR(25) NOT NULL,
  salary  MONEY       NOT NULL
)


CREATE UNIQUE CLUSTERED INDEX idx_depth_first
  ON dbo.Employees(hid);
CREATE UNIQUE INDEX idx_breadth_first
  ON dbo.Employees(lvl, hid);
CREATE UNIQUE INDEX idx_empid
  ON dbo.Employees(empid);
  
/*Example 1 Creating Sparse Columns */  
CREATE TABLE Emp001
(
EmpID INT NOT NULL PRIMARY KEY,
EmpName VARCHAR(50) NOT NULL,
EmpSalary int not null,
EmpDiscount int sparse null,
)
 /*Checking Howmuch space is begin used by sparse columns */
 sp_spaceused Product1
/*Example -2 Creating a Table without sparse columns */
CREATE TABLE UnSparsed(ID INT IDENTITY(1,1),
FirstCol INT,
SecondCol VARCHAR(100),
ThirdCol SmallDateTime)
GO
/*Example -3 Creating a Table With Parse columns */
CREATE TABLE Sparsed(ID INT IDENTITY(1,1),
FirstCol INT SPARSE,
SecondCol VARCHAR(100) SPARSE,
ThirdCol SmallDateTime SPARSE)
GO

delete from Sparsed 
delete from UnSparsed
/*Insert data into both the table using 
loop*/
DECLARE @idx INT = 0
WHILE @idx < 50000
BEGIN
INSERT INTO UnSparsed VALUES (1,NULL, NULL)
INSERT INTO Sparsed VALUES (1, NULL, NULL)
SET @idx+=1
END
/*Check the space used by both columns with sparse and 
with out parse columns */
sp_spaceused 'UnSparsed'
go
sp_spaceused 'Sparsed'

/*Example 1 Creating ROWGUIDCOL Column
 similar to Identity colum*/
CREATE TABLE SomeUniqueTable
(
UniqueID UNIQUEIDENTIFIER DEFAULT NEWID(),
EffectiveDate datetime 
)

/*Insert data into the table which
contains ROWGUIDCOL */

INSERT INTO SomeUniqueTable (EffectiveDate) VALUES ('7/1/09')
INSERT INTO SomeUniqueTable (EffectiveDate) VALUES ('8/1/09')

select * from SomeUniqueTable

/*Example using Computed columns */
/*Use Adventure works database*/

ALTER TABLE Sales.CurrencyRate
ADD SetRate 
AS ((AverageRate + EndOfDayRate) / 2)

alter table tbl_Emp
add TotalSal 
as(Emp_Salary + Emp_Salary * 0.2)

select top 5 AverageRate, EndOfDayRate , SetRate
from sales.currencyrate

select * from Sales.CurrencyRate
/*Now add the column to the table as 
computed column*/
ALTER TABLE Sales.CurrencyRate
alter column SetRate 
ADD PERSISTED

select * into ##Producttemp1 from 
Product1
create  table Tab1
(
c1 int,
c2 int
)
ALTER TABLE Tab1
ADD C3 
AS (C1 + C2)

ALTER TABLE Tab1
alter column C3 
ADD PERSISTED




CREATE PARTITION FUNCTION 
SalesBigPF1 (datetime)
AS RANGE LEFT FOR VALUES
('12/31/2004 23:59:59.997', '12/31/2005 23:59:59.997',
'12/31/2006 23:59: 59.997', '12/31/2007 23:59:59.997',
'12/31/2008 23:59:59.997')

/*Example 1 Insert Over DML which can be implemented
  using Output clause*/
/*OUTPUT clause has accesses to 
inserted and deleted tables (virtual tables) 
just like triggers. 
OUTPUT clause can be used to return values 
to client clause. 
OUTPUT clause can be used with 
INSERT, UPDATE, or DELETE to identify the 
actual rows affected by these statements.
OUTPUT clause can generate table variable, 
a permanent table, or temporary table*/

/*Example 1 : OUTPUT clause into Table 
  with INSERT statement*/
  CREATE TABLE TestTable
  (  
  ID INT, 
  TEXTVal VARCHAR(100)
  )
----Creating temp table to store ovalues of OUTPUT clause
DECLARE @TmpTable TABLE 
(
ID INT, TEXTVal VARCHAR(100))
----Insert values in real table as well use OUTPUT clause to insert
----values in the temp table.
INSERT TestTable (ID, TEXTVal)
OUTPUT Inserted.ID, Inserted.TEXTVal INTO @TmpTable
VALUES (1,'FirstVal')
INSERT TestTable (ID, TEXTVal)
OUTPUT Inserted.ID, Inserted.TEXTVal INTO @TmpTable
VALUES (2,'SecondVal')
----Check the values in the temp table and real table
----The values in both the tables will be same
SELECT * FROM @TmpTable
SELECT * FROM TestTable

/*Example 2 : OUTPUT clause with INSERT 
statement*/

INSERT TestTable (ID, TEXTVal)
OUTPUT Inserted.ID, Inserted.TEXTVal
VALUES (1,'FirstVal')
INSERT TestTable (ID, TEXTVal)
OUTPUT Inserted.ID, Inserted.TEXTVal
VALUES (2,'SecondVal')
drop table TestTable 

/*Example 3 : OUTPUT clause into Table*/ 
CREATE TABLE TestTable (ID INT, TEXTVal VARCHAR(100))
----Creating temp table to store ovalues of OUTPUT clause
DECLARE @TmpTable TABLE (ID_New INT, TEXTVal_New VARCHAR(100),ID_Old INT, TEXTVal_Old VARCHAR(100))
----Insert values in real table
INSERT TestTable (ID, TEXTVal)
VALUES (1,'FirstVal')
INSERT TestTable (ID, TEXTVal)
VALUES (2,'SecondVal')
----Update the table and insert values in temp table using Output clause
UPDATE TestTable
SET TEXTVal = 'NewValue'
OUTPUT Inserted.ID, Inserted.TEXTVal, Deleted.ID, Deleted.TEXTVal INTO @TmpTable
WHERE ID IN (1,2)
----Check the values in the temp table and real table
----The values in both the tables will be same
SELECT * FROM @TmpTable
SELECT * FROM TestTable
/*Returns size and fragmentation information for the data and indexes of the specified table or view*/
SELECT * FROM sys.dm_db_index_physical_stats
(DB_ID(N'HRMS_DB'), OBJECT_ID(N'Sparsed'), NULL, NULL , 'DETAILED');
/*This command is used to scan the current DB
and display the pages and extens and fragemention*/
DBCC SHOWCONTIG('tbl_Dept')
SELECT * FROM sys.dm_db_index_physical_stats('HRMS_DB','tbl_Emp' , NULL, NULL , 'LIMITED');

/* To display total pagesize,datapage size,
used pages on a database*/
select * from sys.allocation_units
/*To display the rows spread accross
the pages in a table*/ 
DBCC CHECKTABLE ('tbl_Emp')
/*To check the overall Database and tables
with rows spread across the pages*/
DBCC CHECKDB (HRMS1)
/*The total number of extents = 8958, 
  used pages = 71022, 
  and reserved pages = 71651 in this 
  database.(number of mixed extents = 102, mixed pages = 803) 
  in this database.*/
DBCC CHECKALLOC(AdventureWorks);
/*To Clean the Table and reclaim space from 
  dropped variable-length columns in tables*/
/*To Do this we need to do the following Steps*/
/*Step 1: Create a table with some columns*/
CREATE TABLE CleanTableTest
    (FileName nvarchar(4000), 
    DocumentSummary nvarchar(max),
    Document varbinary(max)
    );
GO

INSERT INTO CleanTableTest
    SELECT REPLICATE(FileName, 1000), 
           DocumentSummary, 
           Document
    FROM AdventureWorks.Production.Document;
GO


/*Step 2: Check the Space occupied by the table*/

-- Populate the table with data from the Production.Document table.
-- Verify the current page counts and average space used in the dbo.CleanTableTest table.
DECLARE @db_id SMALLINT;
DECLARE @object_id INT;
SET @db_id = DB_ID(N'HRMS_DB');
SET @object_id = OBJECT_ID(N'HRMS_DB.dbo.CleanTableTest');
SELECT alloc_unit_type_desc, 
       page_count, 
       avg_page_space_used_in_percent, 
       record_count
FROM sys.dm_db_index_physical_stats(@db_id, @object_id, NULL, NULL , 'Detailed');
GO
-- Drop two variable-length columns from the table.
ALTER TABLE CleanTableTest
DROP COLUMN FileName, Document;
GO
-- Verify the page counts and average space used in the dbo.CleanTableTest table
-- Notice that the values have not changed.
DECLARE @db_id SMALLINT;
DECLARE @object_id INT;
SET @db_id = DB_ID(N'HRMS_DB');
SET @object_id = OBJECT_ID(N'HRMS_DB.dbo.CleanTableTest');
SELECT alloc_unit_type_desc, 
       page_count, 
       avg_page_space_used_in_percent, 
       record_count
FROM sys.dm_db_index_physical_stats(@db_id, @object_id, NULL, NULL , 'Detailed');
GO
-- Run DBCC CLEANTABLE.
DBCC CLEANTABLE (HRMS_DB,'CleanTableTest');
GO
-- Verify the values in the dbo.CleanTableTest table after the DBCC CLEANTABLE command.
DECLARE @db_id SMALLINT;
DECLARE @object_id INT;
SET @db_id = DB_ID(N'AdventureWorks2012');
SET @object_id = OBJECT_ID(N'AdventureWorks2012.dbo.CleanTableTest');
SELECT alloc_unit_type_desc, 
       page_count, 
       avg_page_space_used_in_percent, 
       record_count
FROM sys.dm_db_index_physical_stats(@db_id, @object_id, NULL, NULL , 'Detailed');
GO

/*Step 3:drop the columns on the table
and see the space*/
alter table tbl_emp
drop column emp_name
/*Step 4: Now run the below command to see the 
space is reduced*/

DBCC CleanTable(AdventureWorks,'Production.Document', 0)

/*To check the FileGroups and it's 
Size in a particular DB*/
DBCC CHECKFILEGROUP 
/*Flushes the distributed query 
connection cache used by 
distributed queries against an 
instance of Microsoft SQL Server*/
DBCC FREESESSIONCACHE 
/*Removes all elements from the plan 
cache, removes a specific plan 
from the plan cache by specifying a 
plan handle or SQL handle, 
or removes all cache entries 
associated with a specified resource 
pool */
DBCC FREEPROCCACHE 
/*Defragments indexes of the specified 
  table or view*/
DBCC INDEXDEFRAG 
(AdventureWorks, 'Production.Product', 
PK_Product_ProductID)
/*displays current query optimization 
statistics for a table or indexed 
view. The query optimizer uses 
statistics to estimate the cardinality 
or number of rows in the query result, 
which enables the query optimizer 
to create a high quality query plan*/

DBCC SHOW_STATISTICS
('Person.Address', 
AK_Address_rowguid) WITH HISTOGRAM;
/*Checks the current identity value 
for the specified table in 
SQL Server 2008 and, 
if it is needed, changes the 
identity value. You can also use 
DBCC CHECKIDENT to manually set a 
new current identity value for the 
identity column*/
/*To Reterive the current identity value
of the given table*/
DBCC CHECKIDENT('Emp_121') 
/*Force the Current Identity values to a 
New value*/
DBCC CHECKIDENT ('Emp_121', RESEED, 20);
/*Update the corrects pages and row 
  count inaccuracies in the catalog 
  views which is useful for row and page
  calculations*/
DBCC UPDATEUSAGE (SampleDB,'tbl_Emp01');

/*To Check all enable and disable 
constraints on a table*/
DBCC CHECKCONSTRAINTS 
WITH ALL_CONSTRAINTS;
/*To Check constraints on a specific
table*/
DBCC CHECKCONSTRAINTS(tbl_Emp01);
/*We can use the DBCC INPUTBUFFER 
to start a new connection when the query
is running on another connection*/
CREATE TABLE T10
(Col1 int, Col2 char(3));
GO
DECLARE @i int = 0;
BEGIN TRAN
SET @i = 0;
WHILE (@i < 1000)
BEGIN
INSERT INTO T10 VALUES 
(@i, CAST(@i AS char(3)));
SET @i += 1;
END;
COMMIT TRAN;
--Start new connection #2.
DBCC INPUTBUFFER (53);
/*To Display the Current information 
which is set on the following options*/
DBCC USEROPTIONS;
/*DBCC OPENTRAN display the information of uid,name,
LSN etc..*/
CREATE TABLE T5
(Col1 int, 
Col2 char(3));
GO
BEGIN TRAN
INSERT INTO T5 VALUES (101, 'abc');
GO
DBCC OPENTRAN;
ROLLBACK TRAN;
GO
DROP TABLE T1;
GO

/*Releases all unused cache entries 
from all caches. The SQL Server 
Database Engine proactively cleans 
up unused cache entries in the 
background to make memory available 
for current entries*/
DBCC FREESYSTEMCACHE ('ALL') 
WITH MARK_IN_USE_FOR_REMOVAL;

/*Cleans all cache palns associated with
a resource pool*/
SELECT * FROM sys.dm_resource_governor_resource_pools;
GO
DBCC FREEPROCCACHE ('default');
GO

/*Removes all clean buffers from the buffer pool.*/
DBCC DROPCLEANBUFFERS









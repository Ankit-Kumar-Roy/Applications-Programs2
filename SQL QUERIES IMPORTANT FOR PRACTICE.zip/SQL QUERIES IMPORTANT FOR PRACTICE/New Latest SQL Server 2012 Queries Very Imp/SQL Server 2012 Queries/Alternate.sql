SELECT orderid, orderdate, custid, filler

FROM dbo.Orders

ORDER BY orderdate DESC, orderid DESC

OFFSET 50 ROWS FETCH NEXT 10 ROWS ONLY;

Here�s the alternative to this query using row numbers:

WITH C AS

(

  SELECT orderid, orderdate, custid, filler,

    ROW_NUMBER() OVER(ORDER BY orderdate DESC, orderid DESC) AS rownum

  FROM dbo.Orders

)

SELECT *

FROM C

WHERE rownum BETWEEN 51 AND 60

ORDER BY rownum;
/* Working with Trnasction Log files to test and see how the log file grows*/
USE master;
GO 
/*Step 1: If the Databse already exists then delete the DB*/
IF DB_ID('MyMessages') IS NOT NULL
DROP DATABASE MyMessages; 
GO 
/*Step 2:Create a New DB */
CREATE DATABASE MyMessages ON PRIMARY 
(  NAME = N'MyMessages' 
,FILENAME = N'D:\SampleTransLog\MyMessages.mdf' 
, SIZE = 199680KB 
, FILEGROWTH = 16384KB ) 
	LOG ON 
	   (  NAME = N'MyMessages_log'
    , FILENAME = N'D:\SampleTransLog\MyMessages.ldf' 
	    , SIZE = 2048KB 
	    , FILEGROWTH = 2048KB 
	); 
	GO 
/*Step 3: Alter the database and change the recovery model to full*/
	ALTER DATABASE MyMessages SET RECOVERY FULL; 
	GO 

/*Step 4: Now backup the database with full recovery model*/
USE master; 
GO 
BACKUP DATABASE MyMessages 
TO DISK ='D:\SQLSERVERBACKUP\MyMessages_full.bak' 
WITH INIT; 
GO 

/*Step 5: Create a table */
USE MyMessages; 
GO 
CREATE TABLE dbo.Messages 
( 
MessageText nvarchar(200) NOT NULL , 
MessageDate datetime2 NOT NULL 
); 
GO

/*Step 6: Fill the table using some transactional activites*/
USE MyMessages; 
GO 
INSERT INTO dbo.Messages 
( MessageText , 
MessageDate 
) 
VALUES ( 'A first message','2013-02-26 17:54:47'); 
GO 
--BEGIN TRANSACTION 
UPDATE dbo.Messages 
SET MessageText = 'A newer message' 
-- ROLLBACK TRANSACTION

/*Step 7 : Lets insert some 1.3 million records in the table*/
USE MyMessages; 
GO 
INSERT INTO Messages 
(MessageText, MessageDate) 
SELECT TOP 1000000 
REPLICATE('a', 200),GETDATE() FROM msdb.sys.columns a 
CROSS JOIN msdb.sys.columns b; 
GO 

DBCC SQLPERF(LOGSPACE); 

BACKUP LOG MyMessages 
TO DISK = 'D:\SQLSERVERBACKUP\MyMessages_log1.trn' 
WITH INIT; 
GO 

USE master; 
GO 
ALTER DATABASE MyMessages 
ADD LOG FILE (NAME = N'MyMessages_log2', 
FILENAME = N'D:\SampleTransLog\MyMessages2.ldf',SIZE = 512000KB,FILEGROWTH = 512000KB ); 
go

use MyMessages 

BACKUP LOG MyMessages 
TO DISK = 'D:\SQLSERVERBACKUP\MyMessages_log2.trn' 
WITH INIT; 
GO 



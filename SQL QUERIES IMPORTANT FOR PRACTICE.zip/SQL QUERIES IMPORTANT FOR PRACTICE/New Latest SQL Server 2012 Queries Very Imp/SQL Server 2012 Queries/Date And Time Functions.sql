/*Date time Functions Newly Added int SQL SERVER 2012*/

/* EOMONTH : Returns the last day of the month that contains the specified date, 
with an optional offset*/
/*Example 1:*/
DECLARE @date DATETIME = '12/1/2011';
SELECT EOMONTH ( @date ) AS Result;
GO
/*Example 2 We don't require a convertion it will
implicity convert varchar to date and display last date */
DECLARE @date VARCHAR(255) = '12/1/2011';
SELECT EOMONTH ( @date ) AS Result;
GO
/*Example 3: to display next,last,current month last dates*/
DECLARE @date DATETIME = GETDATE();
SELECT EOMONTH ( @date ) AS 'This Month';
SELECT EOMONTH ( @date, 1 ) AS 'Next Month';
SELECT EOMONTH ( @date, -1 ) AS 'Last Month';
GO

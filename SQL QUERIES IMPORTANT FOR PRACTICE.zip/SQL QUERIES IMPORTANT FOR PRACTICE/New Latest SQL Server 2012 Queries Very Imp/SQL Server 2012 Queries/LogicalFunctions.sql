/*Logical functions*/
/* CHOOSE : Returns the specified itemsfromthe list using the index number*/
SELECT CHOOSE ( 3, 'Manager', 'Director', 'Developer', 'Tester' ) AS Result;
/*IIF : Returns one of two values, depending on whether the Boolean expression 
  evaluates to true or false*/
DECLARE @a int = 45, 
@b int = 40;
SELECT IIF ( @a > @b, 'TRUE', 'FALSE' ) AS Result;

/*Example IIF return NULL Values*/
DECLARE @P INT = NULL, @S INT = NULL;
SELECT IIF ( 45 > 30, @p, @s ) AS Result;

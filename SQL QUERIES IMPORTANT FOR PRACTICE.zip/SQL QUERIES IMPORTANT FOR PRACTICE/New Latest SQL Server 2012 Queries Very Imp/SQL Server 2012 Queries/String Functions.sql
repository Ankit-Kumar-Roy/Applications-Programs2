/*STRING FUNCTIONS*/
/*CONCAT : Returns a string that is the result of concatenating two or more string values */

/*Example 1: */
SELECT CONCAT ( 'Happy ', 'Birthday ', 11, '/', '25' ) AS Result
/*Example 2 Using CONCAT with NULL Values*/
CREATE TABLE #temp (
    emp_name nvarchar(200) NOT NULL,
    emp_middlename nvarchar(200) NULL,
    emp_lastname nvarchar(200) NOT NULL
);
INSERT INTO #temp VALUES( 'Name', NULL, 'Lastname' );
SELECT CONCAT( emp_name, emp_middlename, emp_lastname ) AS Result
FROM #temp;

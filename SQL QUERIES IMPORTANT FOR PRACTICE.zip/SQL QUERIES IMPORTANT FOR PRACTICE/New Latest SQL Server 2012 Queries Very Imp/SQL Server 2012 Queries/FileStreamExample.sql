/* Create a FileStream Database*/
CREATE DATABASE TestFileStream 
ON
PRIMARY(NAME = TestFileStreamDB, 
FILENAME = 'D:\FTB\TestFileStreamDB.mdf'
),FILEGROUP TestFileStreamFS 
  CONTAINS FILESTREAM( 
  NAME = TestFileStreamFS,
  FILENAME = 'D:\FTB\TestFileStreamFS')
LOG ON(NAME = TestFileStreamLOG,
       FILENAME = 'D:\FTB\TestFileStreamLOG.ldf')

/*Now Create a table in the FileTableDB database*/
CREATE TABLE PictureTable
(
PkId int Primary Key IDENTITY (1, 1),
Id uniqueidentifier NOT NULL 
Unique ROWGUIDCOL Default newid(),
Description nvarchar(64) NOT NULL,
FileSummary varbinary(MAX),
FileData varbinary(MAX) FileStream NULL
) 

/*Now Insert data into the table*/
Insert Into PictureTable([Description],[FileData])
Values('Hello Worlddddd', Cast('Hello Worldddddd' As varbinary(max)))

SELECT PkId,Id,Description,FileData,
CAST(FileData As varchar(Max))
FROM PictureTable 

select * from PictureTable

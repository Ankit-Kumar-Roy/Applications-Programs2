--Example 2: On FileStream Storage to
--insert,update,delete from the files
--Step 1: Create a FileStream Storage DB
CREATE DATABASE FileStream_DB1 
ON
PRIMARY(NAME = FileStream_DB1, 
FILENAME = 'D:\FileStreamStorage_1DB\FileStream_DB1.mdf'
),
FILEGROUP FileStreamFS_DB1 
CONTAINS FILESTREAM( 
NAME = FileStreamFS_DB1,
FILENAME = 'D:\FileStreamStorage_1DB\FileStreamFS_DB1')
LOG ON(NAME = FileStream_DB1LOG,
FILENAME = 'D:\FileStreamStorage_1DB\FileStream_DB1LOG.ldf')
--Step 2: Create Table
CREATE TABLE [FileStreamDataStorage]
( 
ID INT IDENTITY(1,1) NOT NULL, 
FileStreamData VARBINARY(MAX) FILESTREAM NULL, 
FileStreamDataGUID UNIQUEIDENTIFIER ROWGUIDCOL NOT NULL UNIQUE DEFAULT NEWSEQUENTIALID(),
[DateTime] DATETIME DEFAULT GETDATE()
)
--Step 3: Insert data into the table
--using bulk copy
INSERT INTO FileStreamDataStorage
(FileStreamData)
SELECT * FROM 
OPENROWSET(BULK N'D:\Data\59.gif',SINGLE_BLOB) AS Document
GO
--Step 4: Display the data stored in the file
SELECT ID
, CAST([FileStreamData] AS VARCHAR) as [FileStreamData]
, FileStreamDataGUID
, [DateTime]
FROM [FileStreamDataStorage]
GO
--Step 5: No we can update the image file
UPDATE [FileStreamDataStorage]
SET [FileStreamData] = (SELECT *
FROM OPENROWSET(
BULK 'D:\Data\60.gif',
SINGLE_BLOB) AS Document)
WHERE ID = 1 
--No we can delete from the FileStream Storage
DELETE [FileStreamDataStorage]
WHERE ID = 1
GO

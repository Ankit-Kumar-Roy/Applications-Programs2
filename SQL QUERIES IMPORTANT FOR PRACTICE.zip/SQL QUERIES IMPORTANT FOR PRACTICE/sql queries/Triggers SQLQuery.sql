create database dbEmployee
--creating table
create table tblPosition
(
cPositionCode char(4) primary key not null,
cDesignation char(16),
iCurrentStrength int,
iVaccancy int
)

--inserting datas in table
insert into tblPosition values ('P001','developer',32,3)
insert into tblPosition values ('P002','accountant',46,8)
insert into tblPosition values ('P003','manager',50,7)

select * from tblPosition
select * from tblEmployee

--create table employee

create table tblEmployee
(
iEmpId int primary key not null,
cName char(20),
vAddress varchar(50),
iSalary int,
cPositionCode char(4) references tblPosition(cPositionCode)
)

select * from tblEmployee


--inserting rows in Employee table

insert into tblEmployee values (1001,'Rohan','karnataka',43000,'P001')
insert into tblEmployee values (1002,'Mohan','tamil nadu',19500,'P003')
insert into tblEmployee values (1003,'Rohit','bihar',39000,'P002')
insert into tblEmployee values (1004,'Rohan','orissa',35000,'P001')

--create the trigger

create trigger trgUpdatePositionOnAddEmployee
on
tblEmployee
for insert
as
update tblPosition
set iCurrentStrength=iCurrentStrength+1,
iVaccancy=iVaccancy-1
where cPositionCode=(select cPositionCode from inserted)

insert into tblEmployee values (1005,'carrick','madrid',35780,'P002')
select * from tblPosition
select * from tblEmployee

create trigger trgUpdatePositionOnUpdateEmployee
on
tblEmployee
for update
as
update tblPosition
set iCurrentStrength=iCurrentStrength+1,
iVaccancy=iVaccancy-1
where cPositionCode =(select cPositionCode from inserted)

create trigger trgUpdatePositionOnUpdateEmployee1
on
tblEmployee
for update
as
update tblPosition
set iCurrentStrength=iCurrentStrength+1,
iVaccancy=iVaccancy-1
where cPositionCode =(select cPositionCode from deleted) and (select cPositionCode from inserted)

update tblEmployee set cPositionCode='P003' where iEmpId=1005

create trigger trgUpdatePositionOnUpdateEmployee2
on
tblEmployee
for update
as
update tblPosition
set iCurrentStrength=iCurrentStrength+1,
iVaccancy=iVaccancy-1
where cPositionCode exists (select cPositionCode from deleted) and (select cPositionCode from inserted)
















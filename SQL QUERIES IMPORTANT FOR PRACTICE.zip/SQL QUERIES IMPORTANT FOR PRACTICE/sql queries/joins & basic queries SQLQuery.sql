---create database
create database dbEmployee
--creating table
create table tblPosition
(
cPositionCode char(4) primary key not null,
cDesignation char(16),
iCurrentStrength int,
iVaccancy int
)

--inserting datas in table
insert into tblPosition values ('P001','developer',32,3)
insert into tblPosition values ('P002','accountant',46,8)
insert into tblPosition values ('P003','manager',50,7)

select * from tblPosition

--create table employee

create table tblEmployee
(
iEmpId int primary key not null,
cName char(20),
vAddress varchar(50),
iSalary int,
cPositionCode char(4) references tblPosition(cPositionCode)
)

select * from tblEmployee


--inserting rows in Employee table

insert into tblEmployee values (1001,'Rohan','karnataka',43000,'P001')
insert into tblEmployee values (1002,'Mohan','tamil nadu',19500,'P003')
insert into tblEmployee values (1003,'Rohit','bihar',39000,'P002')
insert into tblEmployee values (1004,'Rohan','orissa',35000,'P001')

sp_help tblEmployee

--adding city to employee table

alter table tblEmployee add vCity char(50)


update tblEmployee
set vCity='bhubaneswar'
where iEmpId=1004

select * from tblEmployee where iSalary>20000 and iSalary<50000 

select * from tblEmployee

------------------------------------------------------------------------------------
create table tblDepartment
(
iDeptId int primary key not null,
cDeptName varchar(20),
vDeptLocation varchar(20),
cDeptHead varchar(20)
)

insert into tblDepartment values (1,'Development','bangalore','rajnish')
insert into tblDepartment values (2,'Account','chennai','manish')
insert into tblDepartment values (3,'Finance','pune','ankit')


create table tblNewEmployee
(
iEmpId int primary key not null,
cName char(20),
vAddress varchar(50),
iSalary int,
iDeptId int references tblDepartment(iDeptId)
)

insert into tblNewEmployee values (101,'Rohan','karnataka',79238,1)
insert into tblNewEmployee values (102,'Mohan','tamilnadu',48294,2)
insert into tblNewEmployee values (103,'Johan','mumbai',82374,3)


select * from tblNewEmployee
select * from tblDepartment

--eqi join or inner join

insert into tblNewEmployee values (104,'Sohan','orissa',49322,null)

select cName,cDeptName from tblDepartment join tblNewEmployee 
on tblNewEmployee.iDeptId=tblDepartment.iDeptId

--left outer join
insert into tblNewEmployee
(iEmpId,cName,vAddress,iSalary)values (105,'Suresh','Pune',20000)

select cName,cDeptName from tblNewEmployee left outer join tblDepartment
on tblNewEmployee.iDeptId=tblDepartment.iDeptId 
 

--right outer join
insert into tblDepartment values (4,'HR','Blore','Surya')

select cName,cDeptName from tblNewEmployee right outer join tblDepartment 
on tblNewEmployee.iDeptId=tblDepartment.iDeptId

--to display all the records of Right Table irrespective of any matching values in the left table

select cName,cDeptName from tblNewEmployee full outer join tblDepartment
on tblNewEmployee.iDeptId=tblDepartment.iDeptId


----------------------------------------------------------------------------------------
--column alternative name(column alias)

select cName,iSalary from tblNewEmployee

--temporary column name change
select cName as Employee_name,iSalary as Salary from tblNewEmployee

--for two words use double quote
select cName "Employee name",iSalary as Salary from tblNewEmployee


--how to change names permanently
--sp->stored procedure
sp_rename 'tblNewEmployee.cName','cEmpName','column'
sp_rename 'tblNewEmployee.cName','cEmpName'


--how to add new columns to existing tables

alter table tblNewEmployee add cPhone char(10)
select * from tblNewEmployee

--how to remove columns from the tables

alter table tblNewEmployee drop column cPhone

--Sub Queries

--to display employees in dept 'Development'
select * from tblNewEmployee
where iDeptId=(select iDeptId from tblDepartment where cDeptName='Development')

--Display Employee who belong to Development or Account

select * from tblNewEmployee
where iDeptId in (select iDeptId from tblDepartment where cDeptName = 'Development' OR
cDeptName = 'Account')

--Display Employee who doesn't belong to Development or Account

select * from tblNewEmployee
where iDeptId not in (select iDeptId from tblDepartment where cDeptName = 'Development' OR
cDeptName = 'Account')
									or
select * from tblNewEmployee
where iDeptId in (select iDeptId from tblDepartment where cDeptName <> 'Development' and
cDeptName <> 'Account')


--using computed columns

select cEmpName "Employee Name" ,isalary,isalary+isalary*10/100 "Total Salary with bonus" 
from tblNewEmployee

--Displaying data in ascending and descending order

select * from tblNewEmployee order by iSalary
select * from tblNewEmployee order by iSalary desc

--note-> second sorting will come in place if there is same or
-- common salary of two employees in 1 ordering 
select * from tblNewEmployee order by iSalary desc,cEmpName asc

print REVERSE ('ANKIT')

























